import javafx.application.Application;
import javafx.stage.Stage;


// beans - for property management
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;


// Events
import javafx.event.Event;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;


// Controls
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ListView;


// Layouts
import javafx.scene.layout.StackPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.layout.BorderPane;

import javafx.geometry.Pos;


// Scenes
import javafx.scene.Scene;
import javafx.scene.paint.Color;



// Odd collection of technology demonstrations
// Includes a ListView (from an ObservableList)
// Dynamically created window
// property observer

public class MainApp extends Application {
	
	Model model = Model.getInstance();
	
	@Override // Override the start method in the Application class
	public void start(Stage primaryStage) {
		
		VBox vBox = new VBox(); 
		vBox.setSpacing(10);
		vBox.setAlignment(Pos.CENTER);
		

		Button addCarButton = new Button("Add Car");
		Button quitButton = new Button("Quit");
		HBox hBox = new HBox(); // Hold two buttons in an vBox
		hBox.setAlignment(Pos.CENTER);
		hBox.getChildren().add(quitButton);
		hBox.getChildren().add(addCarButton);


		
		Label label = new Label("New value for list");
		Button addValueButton = new Button("Add");
		
		HBox labelButton = new HBox();
		labelButton.setAlignment(Pos.CENTER);

		labelButton.getChildren().add(label);
		labelButton.getChildren().add(addValueButton);
		
		vBox.getChildren().add(labelButton);
	
		TextField newValueToAdd = new TextField();
		vBox.getChildren().add(newValueToAdd);


		ListView<String> listView = new ListView<String>();
		
		listView.setItems(model.getValues());
		vBox.getChildren().add(listView);
		vBox.getChildren().add(hBox);
		
		addValueButton.setOnAction(
			(event) -> {
				// exclude empty strings
				String value = newValueToAdd.getText().trim();
				if (! value.equals("")) {
					model.getValues().add(value);
					newValueToAdd.setText("");
				}
			}
		);

		
		quitButton.setOnAction(
			(e) -> {
					System.out.println("bye bye!");
					System.exit(0);
				}
		);
		
		
		// Create a dialog box that has a single (dismiss) button on it.
		Stage dialogBox = new Stage();
		dialogBox.setTitle("Car entry dialog box");
		
		
		// dialog components
		TextField yearField = new TextField();
		yearField.setPromptText("Year");
		yearField.setId("year");
		
		TextField modelField = new TextField();
		modelField.setPromptText("Model");
		modelField.setId("model");


		TextField makeField = new TextField();
		makeField.setPromptText("Make");
		makeField.setId("make");


		TextField numSeatsField = new TextField();
		numSeatsField.setPromptText("Number of seats");
		numSeatsField.setId("numOfSeats");


		Button dialogOKButton = new Button("OK");
		Button dialogCancelButton = new Button("Cancel");
		
		HBox dialogButtons = new HBox();
		dialogButtons.getChildren().add(dialogCancelButton);
		dialogButtons.getChildren().add(dialogOKButton);
		dialogButtons.setAlignment(Pos.CENTER);

		
		// layout the dialog components
		VBox dialogVBox = new VBox();

		dialogVBox.getChildren().add(yearField);
		dialogVBox.getChildren().add(modelField);
		dialogVBox.getChildren().add(makeField);
		dialogVBox.getChildren().add(numSeatsField);
		dialogVBox.getChildren().add(dialogButtons);

		
		Scene dialogScene = new Scene(dialogVBox, 200, 200);
		dialogBox.setScene(dialogScene);
		
		
		addCarButton.setOnAction(
				(e) -> {
					dialogBox.show();
				}
			);
		
		// a simple action
		// this should be in a separate controller
		// it should then call on a model action to create a car,
		// then store a car.
		
		dialogOKButton.setOnAction(new DialogOKController(dialogBox));
		dialogCancelButton.setOnAction(new DialogCancelController(dialogBox));


		
		// would you like to get notified about -any- change to the field?
		modelField.textProperty().addListener(
			new ChangeListener<String>() {
				@Override
				public void changed(ObservableValue<? extends String> observable,
					String oldValue, String newValue) {
						System.out.println(" Text Changed to  " + newValue + ")\n");
					}
				}
		);
		
		// set up the window components
		BorderPane borderPane = new BorderPane();
		borderPane.setBottom(vBox);
		BorderPane.setAlignment(vBox, Pos.CENTER);
		Scene scene = new Scene(borderPane, 400, 600);
		primaryStage.setTitle("ControlCircle"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		
		primaryStage.show(); // Display the stage
	}

}
