package com.tournament.dto;

import java.sql.Timestamp;

public class Match {

	private int id;
	private int tournamentId;
	private int refreeId;
	private int teamHome;
	private int teamAway;
	private int teamHomeScore;
	private int teamAwayScore;
	private Timestamp fromTime;
	private Timestamp toTime;
	private int pitch;
	private int round;
	private String teamHomeName;
	private String teamAwayName;
	private String refreeName;
	private String pitchLocation;
	private String tournamentName;
	
	
	
	public String getTournamentName() {
		return tournamentName;
	}
	public void setTournamentName(String tournamentName) {
		this.tournamentName = tournamentName;
	}
	public String getRefreeName() {
		return refreeName;
	}
	public void setRefreeName(String refreeName) {
		this.refreeName = refreeName;
	}
	public String getPitchLocation() {
		return pitchLocation;
	}
	public void setPitchLocation(String pitchLocation) {
		this.pitchLocation = pitchLocation;
	}
	public String getTeamHomeName() {
		return teamHomeName;
	}
	public void setTeamHomeName(String teamHomeName) {
		this.teamHomeName = teamHomeName;
	}
	public String getTeamAwayName() {
		return teamAwayName;
	}
	public void setTeamAwayName(String teamAwayName) {
		this.teamAwayName = teamAwayName;
	}
	public int getRound() {
		return round;
	}
	public void setRound(int round) {
		this.round = round;
	}
	public Match(){
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getTournamentId() {
		return tournamentId;
	}
	public void setTournamentId(int tournamentId) {
		this.tournamentId = tournamentId;
	}
	public int getRefreeId() {
		return refreeId;
	}
	public void setRefreeId(int refreeId) {
		this.refreeId = refreeId;
	}
	public int getTeamHome() {
		return teamHome;
	}
	public void setTeamHome(int teamHome) {
		this.teamHome = teamHome;
	}
	public int getTeamAway() {
		return teamAway;
	}
	public void setTeamAway(int teamAway) {
		this.teamAway = teamAway;
	}
	public int getTeamHomeScore() {
		return teamHomeScore;
	}
	public void setTeamHomeScore(int teamHomeScore) {
		this.teamHomeScore = teamHomeScore;
	}
	public int getTeamAwayScore() {
		return teamAwayScore;
	}
	public void setTeamAwayScore(int teamAwayScore) {
		this.teamAwayScore = teamAwayScore;
	}
	public Timestamp getFromTime() {
		return fromTime;
	}
	public void setFromTime(Timestamp fromTime) {
		this.fromTime = fromTime;
	}
	public Timestamp getToTime() {
		return toTime;
	}
	public void setToTime(Timestamp toTime) {
		this.toTime = toTime;
	}
	public int getPitch() {
		return pitch;
	}
	public void setPitch(int pitch) {
		this.pitch = pitch;
	}
	@Override
	public String toString() {
		return "Match [id=" + id + ", tournamentId=" + tournamentId + ", refreeId=" + refreeId + ", teamHome="
				+ teamHome + ", teamAway=" + teamAway + ", teamHomeScore=" + teamHomeScore + ", teamAwayScore="
				+ teamAwayScore + ", fromTime=" + fromTime + ", toTime=" + toTime + ", pitch=" + pitch + "]";
	}
	
}
