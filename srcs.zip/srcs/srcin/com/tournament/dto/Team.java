package com.tournament.dto;

import java.util.List;

public class Team {

	private int id;
	private String name;
	private int won;
	private int lost;
	private int drawn;
	private List<Player> playerList;
	
	public List<Player> getPlayerList() {
		return playerList;
	}
	public void setPlayerList(List<Player> playerList) {
		this.playerList = playerList;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getWon() {
		return won;
	}
	public void setWon(int won) {
		this.won = won;
	}
	public int getLost() {
		return lost;
	}
	public void setLost(int lost) {
		this.lost = lost;
	}
	public int getDrawn() {
		return drawn;
	}
	public void setDrawn(int drawn) {
		this.drawn = drawn;
	}
	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + ", won=" + won + ", lost=" + lost + ", drawn=" + drawn
				+ ", playerList=" + playerList + "]";
	}
		
}
