package com.tournament.dto;

import java.sql.Timestamp;

public class PitchTime {

	private int id;
	private int pitch_id;
	private Timestamp fromTime;
	private Timestamp toTime;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPitch_id() {
		return pitch_id;
	}
	public void setPitch_id(int pitch_id) {
		this.pitch_id = pitch_id;
	}
	public Timestamp getFromTime() {
		return fromTime;
	}
	public void setFromTime(Timestamp fromTime) {
		this.fromTime = fromTime;
	}
	public Timestamp getToTime() {
		return toTime;
	}
	public void setToTime(Timestamp toTime) {
		this.toTime = toTime;
	}
	
}
