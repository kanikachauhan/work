package com.tournament.dto;

public class Player {

	private int id;
	private String firstName;
	private String lastName;
	private char gender;
	private String address;
	private String contactNumber;
	private String email;
	private String position;
	private double defending;
	private double attacking;
	private double shooting;
	private double speed;
	private double physical;
	
	public Player() {
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public double getDefending() {
		return defending;
	}
	public void setDefending(double defending) {
		this.defending = defending;
	}
	public double getAttacking() {
		return attacking;
	}
	public void setAttacking(double attacking) {
		this.attacking = attacking;
	}
	public double getShooting() {
		return shooting;
	}
	public void setShooting(double shooting) {
		this.shooting = shooting;
	}
	public double getSpeed() {
		return speed;
	}
	public void setSpeed(double speed) {
		this.speed = speed;
	}
	public double getPhysical() {
		return physical;
	}
	public void setPhysical(double physical) {
		this.physical = physical;
	}
	@Override
	public String toString() {
		return "Player [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender
				+ ", address=" + address + ", contactNumber=" + contactNumber + ", email=" + email + ", position="
				+ position + ", defending=" + defending + ", attacking=" + attacking + ", shooting=" + shooting
				+ ", speed=" + speed + ", physical=" + physical + "]";
	}
	
	
}

