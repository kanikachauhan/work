package com.tournament.dto;

import java.sql.Timestamp;

public class RefreeTime {

	private int id;
	private int refreeId;
	private Timestamp fromTime;
	private Timestamp toTime;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getRefreeId() {
		return refreeId;
	}
	public void setRefreeId(int refreeId) {
		this.refreeId = refreeId;
	}
	public Timestamp getFromTime() {
		return fromTime;
	}
	public void setFromTime(Timestamp fromTime) {
		this.fromTime = fromTime;
	}
	public Timestamp getToTime() {
		return toTime;
	}
	public void setToTime(Timestamp toTime) {
		this.toTime = toTime;
	}
	
}
