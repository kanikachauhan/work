package com.tournament.dto;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

import com.tournament.utils.TournamentType;

public class Tournament {

	private int id;
	private String name;
	private Timestamp fromTime;
	private Timestamp toTime;
	private int type;
	private List<Team> teamList;
	
	public List<Team> getTeamList() {
		return teamList;
	}
	public void setTeamList(List<Team> teamList) {
		this.teamList = teamList;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Timestamp getFromTime() {
		return fromTime;
	}
	public void setFromTime(Timestamp fromTime) {
		this.fromTime = fromTime;
	}
	public Timestamp getToTime() {
		return toTime;
	}
	public void setToTime(Timestamp toTime) {
		this.toTime = toTime;
	}
	
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "Tournament [id=" + id + ", name=" + name + ", fromTime=" + fromTime + ", toTime=" + toTime +
				", teamList=" + teamList + "]";
	}
	
}
