package com.tournament.configuration;

import javafx.stage.Stage;

public class StageGenerator {

	public Stage primaryStage = null;
	
	private static StageGenerator stageGenerator;
	
	private StageGenerator(Stage stage) {
		primaryStage = stage;
	}
	
	public static synchronized StageGenerator getCurrentStage(Stage stage) {
		if(stageGenerator == null) {
			stageGenerator = new StageGenerator(stage);
		}
		return stageGenerator;
	}
}
