package com.tournament.configuration;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import com.tournament.utils.Constants;

public class DBConfig {

	private static DBConfig dbConfig = null;
	public Connection connection = null;
	String propertyFileName = "config.properties";
	InputStream inputStream = null;
	String databaseName,hostUrl,username,password,driver = null;

	
	public Connection getConnection() {
		return connection;
	}
	private DBConfig() {
		try {
			Properties properties = new Properties();
			/*inputStream = getClass().getClassLoader().getResourceAsStream(propertyFileName);
			if (inputStream != null) {
				properties.load(inputStream);
				databaseName = properties.getProperty(Constants.DATABASE_NAME);
				hostUrl = properties.getProperty(Constants.HOST_URL);
				username = properties.getProperty(Constants.USER_NAME);
				password = properties.getProperty(Constants.PASS_WORD);
				driver = properties.getProperty(Constants.DATABASE_DRIVER);*/
				databaseName = "tournament_manager";
				hostUrl = "jdbc:mysql://localhost:3306/";
				username = "root";
				password = "root";
				driver = "com.mysql.cj.jdbc.Driver";
				Class.forName(driver).newInstance();
				connection = (Connection)DriverManager.getConnection(hostUrl+databaseName,username,password);
//			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static synchronized DBConfig getDatabaseConnection() {
		if(dbConfig == null) {
			dbConfig = new DBConfig();
		}
		return dbConfig;
	}
}
