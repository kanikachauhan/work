package com.tournament.controllers.refree;

import java.net.URL;
import java.sql.Timestamp;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.dto.RefreeTime;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class GetRefreeScheduleController implements Initializable{

	
	@FXML
	BorderPane borderPane;
	@FXML
	Button closeBtn;
	private List<RefreeTime> refreeTimeList;
	TableView<RefreeTime> table = new TableView<RefreeTime>();
	TableColumn<RefreeTime,Timestamp> one = new TableColumn<RefreeTime, Timestamp>("From Time");
	TableColumn<RefreeTime,Timestamp> two = new TableColumn<RefreeTime, Timestamp>("To Time");
	public GetRefreeScheduleController(List<RefreeTime> refreeTimeList) {
		this.refreeTimeList = refreeTimeList;
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		one.setCellValueFactory(new PropertyValueFactory<RefreeTime, Timestamp>("fromTime"));
		one.setResizable(true);
		two.setCellValueFactory(new PropertyValueFactory<RefreeTime, Timestamp>("toTime"));
		two.setResizable(true);
		table.getColumns().addAll(one,two);
		table.setMaxWidth(150);
		table.setMaxHeight(500);
		table.setEditable(true);
		table.setVisible(true);
		table.setItems(FXCollections.observableList(refreeTimeList));
		borderPane.setCenter(table);
	}
	
	public void close() {
		Stage stage = (Stage) closeBtn.getScene().getWindow();
	    stage.close();
	}
}
