package com.tournament.controllers.refree;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Refree;
import com.tournament.repositories.RefreeOperations;
import com.tournament.utils.Constants;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

public class DeleteRefreeController implements Initializable {

	Refree selectedRefree = null;
	@FXML
	private Label errorLabel;
	@FXML
	private BorderPane borderPane;
	@FXML
	private HBox resultBox;
	TableView<Refree> table = new TableView<Refree>();
	TableColumn<Refree, Integer> idColumn = new TableColumn<Refree, Integer>("Id");
	TableColumn<Refree, String> firstNameColumn = new TableColumn<Refree, String>("FirstName");
	TableColumn<Refree, String> lastNameColumn = new TableColumn<Refree, String>("LastName");
	TableColumn<Refree, Integer> ageColumn = new TableColumn<Refree, Integer>("Age");
	TableColumn<Refree, Character> genderColumn = new TableColumn<Refree, Character>("Gender");
	TableColumn<Refree, String> addressColumn = new TableColumn<Refree, String>("Address");
	TableColumn<Refree, String> contactNumberColumn = new TableColumn<Refree, String>("ContactNumber");
	TableColumn<Refree, String> emailColumn = new TableColumn<Refree, String>("Email");
	RefreeOperations refreeOperations = new RefreeOperations();

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			idColumn.setCellValueFactory(new PropertyValueFactory<Refree, Integer>("id"));
			firstNameColumn.setCellValueFactory(new PropertyValueFactory<Refree, String>("firstName"));
			firstNameColumn.setResizable(true);
			lastNameColumn.setCellValueFactory(new PropertyValueFactory<Refree, String>("lastName"));
			lastNameColumn.setResizable(true);
			ageColumn.setCellValueFactory(new PropertyValueFactory<Refree, Integer>("age"));
			ageColumn.setResizable(true);
			genderColumn.setCellValueFactory(new PropertyValueFactory<Refree, Character>("gender"));
			genderColumn.setResizable(true);
			addressColumn.setCellValueFactory(new PropertyValueFactory<Refree, String>("address"));
			addressColumn.setResizable(true);
			contactNumberColumn.setCellValueFactory(new PropertyValueFactory<Refree, String>("contactNumber"));
			contactNumberColumn.setResizable(true);
			emailColumn.setCellValueFactory(new PropertyValueFactory<Refree, String>("email"));
			emailColumn.setResizable(true);
			table.setItems(FXCollections.observableList(refreeOperations.list()));
			table.getColumns().addAll(idColumn, firstNameColumn, lastNameColumn, genderColumn, emailColumn, ageColumn,
					contactNumberColumn, addressColumn);
			table.setMaxWidth(600);
			table.setMaxHeight(500);
			table.setEditable(true);
			table.setVisible(true);
			resultBox.getChildren().add(table);
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			borderPane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void deleteRefree() {
		int index = table.getSelectionModel().getSelectedIndex();
		if (index == -1) {
			errorLabel.setText("Select One Value For Deletion");
			return;
		}
		selectedRefree = table.getItems().get(index);
		boolean deletionStatus = refreeOperations.delete(selectedRefree.getId());
		if (deletionStatus) {
			table.getItems().remove(index);
		}
	}

}
