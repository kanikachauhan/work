package com.tournament.controllers.refree;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Refree;
import com.tournament.dto.RefreeTime;
import com.tournament.repositories.RefreeOperations;
import com.tournament.repositories.RefreeTimeOperations;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ListRefreeController implements Initializable {

	@FXML
	private BorderPane borderPane;
	@FXML
	VBox vbox;
	TableView<Refree> table = new TableView<Refree>();
	TableColumn<Refree, Integer> idColumn = new TableColumn<Refree, Integer>("Id");
	TableColumn<Refree, String> firstNameColumn = new TableColumn<Refree, String>("FirstName");
	TableColumn<Refree, String> lastNameColumn = new TableColumn<Refree, String>("LastName");
	TableColumn<Refree, Integer> ageColumn = new TableColumn<Refree, Integer>("Age");
	TableColumn<Refree, Character> genderColumn = new TableColumn<Refree, Character>("Gender");
	TableColumn<Refree, String> addressColumn = new TableColumn<Refree, String>("Address");
	TableColumn<Refree, String> contactNumberColumn = new TableColumn<Refree, String>("ContactNumber");
	TableColumn<Refree, String> emailColumn = new TableColumn<Refree, String>("Email");
	RefreeOperations refreeOperations = new RefreeOperations();

	RefreeTimeOperations refreeTimeOperations = new RefreeTimeOperations();

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			idColumn.setCellValueFactory(new PropertyValueFactory<Refree, Integer>("id"));
			firstNameColumn.setCellValueFactory(new PropertyValueFactory<Refree, String>("firstName"));
			firstNameColumn.setResizable(true);
			lastNameColumn.setCellValueFactory(new PropertyValueFactory<Refree, String>("lastName"));
			lastNameColumn.setResizable(true);
			ageColumn.setCellValueFactory(new PropertyValueFactory<Refree, Integer>("age"));
			ageColumn.setResizable(true);
			genderColumn.setCellValueFactory(new PropertyValueFactory<Refree, Character>("gender"));
			genderColumn.setResizable(true);
			addressColumn.setCellValueFactory(new PropertyValueFactory<Refree, String>("address"));
			addressColumn.setResizable(true);
			contactNumberColumn.setCellValueFactory(new PropertyValueFactory<Refree, String>("contactNumber"));
			contactNumberColumn.setResizable(true);
			emailColumn.setCellValueFactory(new PropertyValueFactory<Refree, String>("email"));
			emailColumn.setResizable(true);
			table.setItems(FXCollections.observableList(refreeOperations.list()));
			table.getColumns().addAll(idColumn, firstNameColumn, lastNameColumn, genderColumn, emailColumn, ageColumn,
					contactNumberColumn, addressColumn);
			table.setMaxWidth(550);
			table.setMaxHeight(500);
			table.setEditable(true);
			table.setVisible(true);
			table.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Refree>() {
				@Override
				public void changed(ObservableValue<? extends Refree> arg0, Refree arg1, Refree arg2) {
					int index = table.getSelectionModel().getSelectedIndex();
					if (index != -1) {
						List<Refree> refreList = refreeOperations.list();
						Refree selectedRefree = refreList.get(index);
						List<RefreeTime> lst = refreeTimeOperations.getList(selectedRefree.getId());
						refreeScheduleView(lst);
					}
				}

			});
			vbox.getChildren().add(table);
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			borderPane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void refreeScheduleView(List<RefreeTime> refreeTimeList) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tournament/fxml/refree/GetRefreeSchedule.fxml"));
			loader.setController(new GetRefreeScheduleController(refreeTimeList));
			Parent root = loader.load();
			Scene scene = new Scene(root, 250, 500);
			Stage primaryStage = new Stage();
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
