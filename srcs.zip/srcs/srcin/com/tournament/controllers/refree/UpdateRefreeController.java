package com.tournament.controllers.refree;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Refree;
import com.tournament.repositories.RefreeOperations;
import com.tournament.utils.Utils;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class UpdateRefreeController implements Initializable {

	@FXML
	private BorderPane borderPane;
	@FXML
	private Label errorLabel;
	TableView<Refree> table = new TableView<Refree>();
	TableColumn<Refree, Integer> idColumn = new TableColumn<Refree, Integer>("Id");
	TableColumn<Refree, String> firstNameColumn = new TableColumn<Refree, String>("FirstName");
	TableColumn<Refree, String> lastNameColumn = new TableColumn<Refree, String>("LastName");
	TableColumn<Refree, Integer> ageColumn = new TableColumn<Refree, Integer>("Age");
	TableColumn<Refree, Character> genderColumn = new TableColumn<Refree, Character>("Gender");
	TableColumn<Refree, String> addressColumn = new TableColumn<Refree, String>("Address");
	TableColumn<Refree, String> contactNumberColumn = new TableColumn<Refree, String>("ContactNumber");
	TableColumn<Refree, String> emailColumn = new TableColumn<Refree, String>("Email");
	RefreeOperations refreeOperations = new RefreeOperations();

	@FXML
	private TextField firstName, contactNumber, email, lastName, age, fromTimeField, toTimeField;
	@FXML
	private TextArea address;
	@FXML
	private ChoiceBox<Character> genderBox;
	List<Character> genderList = new ArrayList<Character>();
	Refree selectedRefree = null;
	List<Refree> refreeList = null;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			genderList.add('M');
			genderList.add('F');
			genderBox.setItems(FXCollections.observableList(genderList));
			genderBox.setValue(genderList.get(0));
			idColumn.setCellValueFactory(new PropertyValueFactory<Refree, Integer>("id"));
			firstNameColumn.setCellValueFactory(new PropertyValueFactory<Refree, String>("firstName"));
			firstNameColumn.setResizable(true);
			lastNameColumn.setCellValueFactory(new PropertyValueFactory<Refree, String>("lastName"));
			lastNameColumn.setResizable(true);
			ageColumn.setCellValueFactory(new PropertyValueFactory<Refree, Integer>("age"));
			ageColumn.setResizable(true);
			genderColumn.setCellValueFactory(new PropertyValueFactory<Refree, Character>("gender"));
			genderColumn.setResizable(true);
			addressColumn.setCellValueFactory(new PropertyValueFactory<Refree, String>("address"));
			addressColumn.setResizable(true);
			contactNumberColumn.setCellValueFactory(new PropertyValueFactory<Refree, String>("contactNumber"));
			contactNumberColumn.setResizable(true);
			emailColumn.setCellValueFactory(new PropertyValueFactory<Refree, String>("email"));
			emailColumn.setResizable(true);
			refreeList = refreeOperations.list();
			table.setItems(FXCollections.observableList(refreeList));
			table.getColumns().addAll(idColumn, firstNameColumn, lastNameColumn, genderColumn, emailColumn, ageColumn,
					contactNumberColumn, addressColumn);
			table.setMaxWidth(550);
			table.setMaxHeight(500);
			table.setEditable(true);
			table.setVisible(true);
			borderPane.setLeft(table);
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			borderPane.setTop(root);
			table.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Refree>() {

				@Override
				public void changed(ObservableValue<? extends Refree> observable, Refree oldValue, Refree newValue) {
					int index = table.getSelectionModel().getSelectedIndex();
					if (index != -1) {
						selectedRefree = table.getItems().get(index);
						firstName.setText(selectedRefree.getFirstName());
						lastName.setText(selectedRefree.getLastName());
						genderBox.setValue(selectedRefree.getGender());
						email.setText(selectedRefree.getEmail());
						age.setText(Integer.toString(selectedRefree.getAge()));
						contactNumber.setText(selectedRefree.getContactNumber());
						address.setText(selectedRefree.getAddress());
						if (selectedRefree.getFromTime() != null) {
							fromTimeField.setText(selectedRefree.getFromTime().toString());
						}
						if (selectedRefree.getToTime() != null) {
							toTimeField.setText(selectedRefree.getToTime().toString());
						}
					}
				}
			});
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void updateRefree() {
		try {
			Refree refree = new Refree();
			int index = table.getSelectionModel().getSelectedIndex();
			if (index == -1) {
				errorLabel.setText("Select One Value For Update");
				return;
			}
			if (!Utils.validateRegex("^\\w{1,45}$", firstName.getText())) {
				errorLabel.setText("FirstName should have length min:1 and max:45");
				return;
			}
			if (!Utils.validateRegex("^\\w{1,45}$", lastName.getText())) {
				errorLabel.setText("LastName should have length min:1 and max:45");
				return;
			}
			if (!Utils.validateRegex("^(.+)@(.+)$", email.getText())) {
				errorLabel.setText("Invalid Email");
				return;
			}
			if (address.getText().length() < 5 || address.getText().length() > 100) {
				errorLabel.setText("Address should have length min:5 and max:100");
				return;
			}
			if (!Utils.validateRegex("\\d{7,20}", contactNumber.getText())) {
				errorLabel.setText("Contact Number should have numbers,min:7 & max:20");
				return;
			}
			if (!Utils.validateRegex("\\d{1,11}", age.getText())) {
				errorLabel.setText("Age should have numbers");
				return;
			}
			refree.setAddress(address.getText());
			refree.setAge(Integer.parseInt(age.getText()));
			refree.setContactNumber(contactNumber.getText());
			refree.setEmail(email.getText());
			refree.setFirstName(firstName.getText());
			refree.setGender(genderBox.getValue());
			refree.setLastName(lastName.getText());
			refree.setId(selectedRefree.getId());
			if(refreeOperations.update(refree)) {
				refreeList.set(index, refree);
				table.setItems(FXCollections.observableArrayList(refreeList));
				errorLabel.setText("Value Updated");
			}
		} catch (Exception e) {
			errorLabel.setText("Error While Adding");
		}
	}
}
