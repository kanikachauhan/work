package com.tournament.controllers.refree;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Refree;
import com.tournament.repositories.RefreeOperations;
import com.tournament.utils.Utils;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class AddRefreeController implements Initializable {

	@FXML
	private TextField firstName, contactNumber, email, lastName, age;
	@FXML
	private TextArea address;
	@FXML
	private ChoiceBox<Character> genderBox;
	RefreeOperations refreeOperations = new RefreeOperations();
	List<Character> genderList = new ArrayList<Character>();
	@FXML
	private Label errorLabel;
	@FXML
	BorderPane refreePane;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			genderList.add('M');
			genderList.add('F');
			genderBox.setItems(FXCollections.observableList(genderList));
			genderBox.setValue(genderList.get(0));
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			refreePane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void saveRefree() {
		try {
			Refree refree = new Refree();
			if (!Utils.validateRegex("^\\w{1,45}$", firstName.getText())) {
				errorLabel.setText("FirstName should have length min:1 and max:45");
				return;
			}
			if (!Utils.validateRegex("^\\w{1,45}$", lastName.getText())) {
				errorLabel.setText("LastName should have length min:1 and max:45");
				return;
			}
			if (!Utils.validateRegex("^(.+)@(.+)$", email.getText())) {
				errorLabel.setText("Invalid Email");
				return;
			}
			if (address.getText().length() < 5 || address.getText().length() > 100) {
				errorLabel.setText("Address should have length min:5 and max:100");
				return;
			}
			if (!Utils.validateRegex("\\d{7,20}", contactNumber.getText())) {
				errorLabel.setText("Contact Number should have numbers,min:7 & max:20");
				return;
			}
			if (!Utils.validateRegex("\\d{1,11}", age.getText())) {
				errorLabel.setText("Age should have numbers");
				return;
			}
			refree.setAddress(address.getText());
			refree.setAge(Integer.parseInt(age.getText()));
			refree.setContactNumber(contactNumber.getText());
			refree.setEmail(email.getText());
			refree.setFirstName(firstName.getText());
			refree.setGender(genderBox.getValue());
			refree.setLastName(lastName.getText());
			refreeOperations.add(refree);
			errorLabel.setText("Values Saved");
		} catch (Exception e) {
			errorLabel.setText("Error While Adding");
		}
	}
}
