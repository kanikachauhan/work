package com.tournament.controllers.tournament;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.dto.Player;
import com.tournament.dto.Team;
import com.tournament.dto.Tournament;
import com.tournament.repositories.TeamOperations;
import com.tournament.repositories.TournamentOperations;
import com.tournament.utils.TournamentType;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Accordion;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

public class NameViewController implements Initializable {

	
	private List<List<Player>> playerBucket;
	@FXML
	private ScrollPane scrollPane;
	@FXML
	Label statusLabel;
	@FXML
	private VBox vbox;
	@FXML
	private Button saveBtn;
	private Tournament tournament;
	List<TextField> tournamentNameFields = new ArrayList<TextField>();
	TournamentOperations tournamentOperations = new TournamentOperations();
	TeamOperations teamOperations = new TeamOperations();
	public NameViewController(List<List<Player>> playerBucket,Tournament tournament) {
		this.playerBucket = playerBucket;
		this.tournament = tournament;
	}
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		for(List<Player> playerList:playerBucket) {
			Accordion accordian = new Accordion();
			 TitledPane titledPane = new TitledPane();
			 ListView<Player> players = new ListView<Player>(FXCollections.observableArrayList(playerList));
			 players.setCellFactory(playerListView -> new PlayerListViewCell());
			 players.setPrefSize(500, 600);
			 titledPane.setText("CShape");
			 GridPane gridPane = new GridPane();
			 Label namelabel  = new Label("Team Name");
			 namelabel.getStyleClass().add("nameLabel");
			 Label listlabel  = new Label("Team List");
			 listlabel.getStyleClass().add("nameLabel");
			 TextField textField = new TextField();
			 gridPane.add(namelabel,1,0);
			 gridPane.add(textField, 2, 0);
			 gridPane.add(listlabel, 1, 1);
			 gridPane.add(players, 2, 1);
			 gridPane.setPrefHeight(600);
			 gridPane.setPrefWidth(500);
			 gridPane.setVgap(10);
			 titledPane.setContent(gridPane);
			 accordian.getPanes().add(titledPane);
			 vbox.getChildren().add(accordian);
			 tournamentNameFields.add(textField);
		}
	}
	public void saveTournamentDetails() {
		int i=0;
		List<Team> teamList = new ArrayList<Team>();
		for(TextField field:tournamentNameFields) {
			String name = field.getText();
			List<Player> players = playerBucket.get(i);
			Team team = new Team();
			team.setName(name);
			team.setPlayerList(players);
			teamList.add(team);
			i = i+1;
		}
		tournament.setTeamList(teamList);
		int key = tournamentOperations.createTournament(tournament);
		tournament.setId(key);
		boolean status = true;
		for(Team team:tournament.getTeamList()) {
			int teamKey = teamOperations.createTeam(team,tournament.getId());
			team.setId(teamKey);
			for(Player player:team.getPlayerList()) {
				 status = teamOperations.createPlayerTeamTournamentMapping(team, player, tournament);
				if(!status) {
					statusLabel.setText("Error in creating tournament");
					break;
				}
			}
		}
		if(status) {
			statusLabel.setText("Tournament Created");
		}
	}
}
