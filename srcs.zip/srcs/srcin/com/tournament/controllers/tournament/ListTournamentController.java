package com.tournament.controllers.tournament;

import java.net.URL;
import java.sql.Timestamp;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Match;
import com.tournament.dto.Tournament;
import com.tournament.repositories.MatchOperations;
import com.tournament.repositories.TournamentOperations;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ListTournamentController implements Initializable {

	TableView<Tournament> table = new TableView<Tournament>();
	TableColumn<Tournament, Integer> idCol = new TableColumn<Tournament, Integer>("Id");
	TableColumn<Tournament, String> nameCol = new TableColumn<Tournament, String>("Name");
	TableColumn<Tournament, Timestamp> fromCol = new TableColumn<Tournament, Timestamp>("From Time");
	TableColumn<Tournament, Timestamp> toCol = new TableColumn<Tournament, Timestamp>("To Time");
	TableColumn<Tournament, Integer> typeCol = new TableColumn<Tournament, Integer>("Type");
	TournamentOperations tournamentOperations = new TournamentOperations();
	MatchOperations matchOperations = new MatchOperations();
	List<Match> matchList = null;
	@FXML
	private VBox vbox;
	@FXML
	BorderPane schedulePane;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			List<Tournament> listAllTournaments = tournamentOperations.list();
			idCol.setCellValueFactory(new PropertyValueFactory<Tournament, Integer>("id"));
			idCol.setResizable(true);
			fromCol.setCellValueFactory(new PropertyValueFactory<Tournament, Timestamp>("fromTime"));
			fromCol.setResizable(true);
			toCol.setCellValueFactory(new PropertyValueFactory<Tournament, Timestamp>("toTime"));
			toCol.setResizable(true);
			nameCol.setCellValueFactory(new PropertyValueFactory<Tournament, String>("name"));
			nameCol.setResizable(true);
			typeCol.setCellValueFactory(new PropertyValueFactory<Tournament, Integer>("type"));
			typeCol.setResizable(true);
			table.getColumns().addAll(idCol, nameCol, fromCol, toCol, typeCol);
			table.setMaxWidth(400);
			table.setMaxHeight(600);
			table.setEditable(true);
			table.setVisible(true);
			table.setItems(FXCollections.observableArrayList(listAllTournaments));
			vbox.getChildren().add(table);
			table.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Tournament>() {
				@Override
				public void changed(ObservableValue<? extends Tournament> observable, Tournament oldValue, Tournament newValue) {
					int index = table.getSelectionModel().getSelectedIndex();
					Tournament tournament = listAllTournaments.get(index);
					matchList = matchOperations.listMatchByTournament(tournament.getId());
					tournamentScheduleView(matchList);
				}
			});
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			schedulePane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void tournamentScheduleView(List<Match> list) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tournament/fxml/tournament/TournamentDetails.fxml"));
			loader.setController(new TournamentDetails(list));
			Parent root = loader.load();
			Scene scene = new Scene(root, 800, 700);
			Stage primaryStage = new Stage();
			primaryStage.setScene(scene);
			primaryStage.show();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
