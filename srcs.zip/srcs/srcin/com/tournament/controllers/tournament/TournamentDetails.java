package com.tournament.controllers.tournament;

import java.net.URL;
import java.sql.Timestamp;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.dto.Match;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TournamentDetails implements Initializable{

	@FXML
	VBox vbox;	
	@FXML
	Button closeBtn;
	@FXML
	ScrollPane scrollPane;
	List<Match> matchList = null;
	TournamentDetails(List<Match> matchList){
		this.matchList = matchList;
	}
	VBox mainBox = new VBox();
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			for (Match match : matchList) {
				VBox vbox = new VBox();
				HBox hboxOne = new HBox();
				Label teamHome = null, teamAway = null;
				teamHome = new Label(Integer.toString(match.getTeamHome()));
				teamAway = new Label(Integer.toString(match.getTeamAway()));
				teamHome.getStyleClass().add("team1");
				teamAway.getStyleClass().add("team1");
				Label vs = new Label("vs");
				vs.getStyleClass().add("vs");
				hboxOne.getChildren().addAll(teamHome, vs, teamAway);
				hboxOne.setPadding(new Insets(20, 100, 10, 50));
				String pitchName = match.getPitchLocation();
				String refreeName = match.getRefreeName();
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.append("Pitch :").append(" ").append(pitchName).append(", Refree :").append(" ")
				.append(refreeName).append(", From Time :").append(" ").append(match.getFromTime())
				.append(", To Time :").append(" ").append(match.getToTime());
				Label detailsLabel = new Label(stringBuilder.toString());
				detailsLabel.getStyleClass().add("detailsLabel");
				vbox.getChildren().addAll(hboxOne, detailsLabel);
				vbox.getStyleClass().add("vb");
				mainBox.getChildren().add(vbox);
			}
			scrollPane.setContent(mainBox);
			scrollPane.setId("sid");
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void closeCurrentStage() {
		try {
			Stage stage = (Stage) closeBtn.getScene().getWindow();
		    stage.close();
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}
}
