package com.tournament.controllers.tournament;

import java.net.URL;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Player;
import com.tournament.repositories.PlayerOperations;
import com.tournament.utils.Constants;
import com.tournament.utils.Utils;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class AddTournamentController implements Initializable {

	PlayerOperations playerOperations = new PlayerOperations();
	List<Player> playerList = null;
	ListView<Player> listViewOfPlayers = null;
	@FXML
	private BorderPane borderPane;
	@FXML
	private TextField numberOfTeams, nameField, fromTime, toTime;
	@FXML
	private DatePicker dateField;
	@FXML
	private Label errorLabel;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			playerList = playerOperations.list();
			listViewOfPlayers = new ListView<Player>(FXCollections.observableList(playerList));
			listViewOfPlayers.setPrefSize(500, 700);
			listViewOfPlayers.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
			listViewOfPlayers.setCellFactory(playerListView -> new PlayerListViewCell());
			borderPane.setRight(listViewOfPlayers);
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			borderPane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	/**used for validating and creating teams 
	 */
	public void createTeams() {
		try {
			if (!Utils.validateRegex("^\\w{1,80}$", nameField.getText())) {
				errorLabel.setText("Invalid Name");
				return;
			}
			if (!Utils.validateRegex("(([0-1]?[0-9])|(2[0-3])):[0-5][0-9]:[0-5][0-9]", fromTime.getText())) {
				errorLabel.setText("Invalid Time");
				return;
			}
			if (!Utils.validateRegex("(([0-1]?[0-9])|(2[0-3])):[0-5][0-9]:[0-5][0-9]", toTime.getText())) {
				errorLabel.setText("Invalid Time");
				return;
			}
			if (!Utils.validateRegex("\\d{1,5}", numberOfTeams.getText())) {
				errorLabel.setText("Invalid Number of teams.");
				return;
			}
			Timestamp fromtime = generateSqlDate(dateField.getValue().toString(), fromTime.getText());
			Timestamp totime = generateSqlDate(dateField.getValue().toString(), toTime.getText());
			if (fromtime.after(totime)) {
				errorLabel.setText("to time should be greater than from time");
				return;
			}
			Date dt = new Date();
			Date dp = new SimpleDateFormat("yyyy-MM-dd").parse(dateField.getValue().toString());
			String currDate = new SimpleDateFormat("yyyy-MM-dd").format(dt);
			Date dp1 = new SimpleDateFormat("yyyy-MM-dd").parse(currDate);
			if (dp.before(dp1)) {
				errorLabel.setText("invalid date choosen");
				return;
			}
			ObservableList<Integer> selectedPlayers = listViewOfPlayers.getSelectionModel().getSelectedIndices();
			if (selectedPlayers == null || selectedPlayers.size() == 0 || selectedPlayers.size() < 2) {
				errorLabel.setText("Select Players for team formation");
				return;
			}
			List<Player> selectedPlayerList = new ArrayList<Player>();
			for (int ind : selectedPlayers) {
				selectedPlayerList.add(playerList.get(ind));
			}
			List<List<Player>> playerBucket = createBuckets(Integer.parseInt(numberOfTeams.getText()),
					selectedPlayerList);
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tournament/fxml/tournament/TournamentTeamResults.fxml"));
			loader.setController(new GeneratedTournamentController(playerBucket, nameField.getText(),
					fromTime.getText(), toTime.getText(), numberOfTeams.getText(), dateField.getValue().toString()));
			Parent root = loader.load();
			Scene scene = new Scene(root, 1200, 700);
			Constants.stageGenerator.primaryStage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private Timestamp generateSqlDate(String date, String time) {
		Timestamp sqlDate = null;
		DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			java.util.Date dt = df1.parse(date + " " + time);
			sqlDate = new Timestamp(dt.getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return sqlDate;
	}
	/**
	 * here the main logic of tournament is done. list of list of players is created. outer list has the count equal to the number of
	 * teams of bucketcount and inner one has the players which constitute a team.
	 * selected player list is iterated and sorted based on each quality and assigned to each team.
	 * @param bucketCount
	 * @param processPlayerList
	 * @return
	 */
	private List<List<Player>> createBuckets(int bucketCount, List<Player> processPlayerList) {
		List<List<Player>> playerBucket = new ArrayList<List<Player>>();
		int temp = 0;
		for (int i = 0; i < bucketCount; i++) {
			playerBucket.add(new ArrayList<Player>());
		}
		while (!processPlayerList.isEmpty()) {
			processPlayerList.sort(Comparator.comparing(Player::getDefending));
			for (int j = 0; j < bucketCount&&processPlayerList.size()>0; j++) {
					playerBucket.get(j).add(processPlayerList.get(0));
					processPlayerList.remove(temp);
			}
			temp = 0;
			processPlayerList.sort(Comparator.comparing(Player::getAttacking));
			for (int j = 0; j < bucketCount&&processPlayerList.size()>0; j++) {
				playerBucket.get(j).add(processPlayerList.get(0));
				processPlayerList.remove(temp);
			}
			temp = 0;
			processPlayerList.sort(Comparator.comparing(Player::getShooting));
			for (int j = 0; j < bucketCount&&processPlayerList.size()>0; j++) {
				playerBucket.get(j).add(processPlayerList.get(0));
				processPlayerList.remove(temp);
			}
			temp = 0;
			processPlayerList.sort(Comparator.comparing(Player::getSpeed));
			for (int j = 0; j < bucketCount&&processPlayerList.size()>0; j++) {
				playerBucket.get(j).add(processPlayerList.get(0));
				processPlayerList.remove(temp);
			}
			temp = 0;
			processPlayerList.sort(Comparator.comparing(Player::getPosition));
			for (int j = 0; j < bucketCount&&processPlayerList.size()>0; j++) {
				playerBucket.get(j).add(processPlayerList.get(0));
				processPlayerList.remove(temp);
			}
			temp = 0;
			processPlayerList.sort(Comparator.comparing(Player::getPhysical));
			for (int j = 0; j < bucketCount&&processPlayerList.size()>0; j++) {
				playerBucket.get(j).add(processPlayerList.get(0));
				processPlayerList.remove(temp);
			}
		}
		return playerBucket;
	}
}
