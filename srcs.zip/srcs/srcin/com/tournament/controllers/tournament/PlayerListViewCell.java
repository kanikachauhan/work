package com.tournament.controllers.tournament;

import java.io.IOException;

import com.tournament.dto.Player;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.layout.GridPane;

public class PlayerListViewCell extends ListCell<Player>{

	@FXML
    private Label label1;

    @FXML
    private Label label2;
    
    @FXML
    private GridPane gridPane;
    
    private FXMLLoader mLLoader;
    
    
    @Override
    protected void updateItem(Player player,boolean empty) {
    	super.updateItem(player,empty);
    	if(empty || player == null) {
    		setText(null);
    	}else {
    		if (mLLoader == null) {
                mLLoader = new FXMLLoader(getClass().getResource("/com/tournament/fxml/tournament/ListCell.fxml"));
                mLLoader.setController(this);
                try {
                    mLLoader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
    		StringBuilder nameBuilder = new StringBuilder();
    		nameBuilder.append(player.getId()).append(" ").append(player.getFirstName()).append(" ").append(" ").append(player.getLastName());
    		label1.setText(nameBuilder.toString());
    		StringBuilder ratingBuilder = new StringBuilder();
    		ratingBuilder.append("A: ").append(player.getAttacking()).append(",D: ").append(player.getDefending())
    		.append(",SH: ").append(player.getShooting()).append(",S: ").append(player.getSpeed())
    		.append(",P: ").append(player.getPosition());
    		label2.setText(ratingBuilder.toString());
    		setText(null);
            setGraphic(gridPane);
    	}
    }
}
