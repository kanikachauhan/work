package com.tournament.controllers.tournament;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Match;
import com.tournament.repositories.PitchOperations;
import com.tournament.repositories.RefreeOperations;
import com.tournament.repositories.TeamOperations;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class GeneratedScheduleController implements Initializable {

	private List<Match> matchList = null;
	@FXML
	private BorderPane schedulePane;
	@FXML
	ScrollPane scrollPane;
	TeamOperations teamOperations = new TeamOperations();
	PitchOperations pitchOperations = new PitchOperations();
	RefreeOperations refreeOperations = new RefreeOperations();
	boolean flag = false;
	VBox mainBox = new VBox();

	public GeneratedScheduleController(List<Match> matchList, boolean flag) {
		this.matchList = matchList;
		this.flag = flag;
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			for (Match match : matchList) {
				VBox vbox = new VBox();
				HBox hboxOne = new HBox();
				Label teamHome = null, teamAway = null;
				if (flag) {
					teamHome = new Label(Integer.toString(match.getTeamHome()));
					teamAway = new Label(Integer.toString(match.getTeamAway()));
				} else {
					teamHome = new Label(teamOperations.getTeamById(match.getTeamHome()).getName());
					teamAway = new Label(teamOperations.getTeamById(match.getTeamAway()).getName());
				}
				teamHome.getStyleClass().add("team1");
				teamAway.getStyleClass().add("team1");
				Label vs = new Label("vs");
				vs.getStyleClass().add("vs");
				hboxOne.getChildren().addAll(teamHome, vs, teamAway);
				hboxOne.setPadding(new Insets(20, 100, 10, 50));
				String pitchName = pitchOperations.getPitchById(match.getPitch()).getLocation();
				String refreeName = refreeOperations.getRefreeById(match.getRefreeId()).getFirstName();
				StringBuilder stringBuilder = new StringBuilder();
				if (flag) {
					stringBuilder.append("Pitch :").append(" ").append(pitchName).append(", Refree :").append(" ")
							.append(refreeName).append(", From Time :").append(" ").append(match.getFromTime())
							.append(", To Time :").append(" ").append(match.getToTime()).append(", Round: ")
							.append(match.getRound());
				} else {
					stringBuilder.append("Pitch :").append(" ").append(pitchName).append(", Refree :").append(" ")
							.append(refreeName).append(", From Time :").append(" ").append(match.getFromTime())
							.append(", To Time :").append(" ").append(match.getToTime());
				}
				Label detailsLabel = new Label(stringBuilder.toString());
				detailsLabel.getStyleClass().add("detailsLabel");
				vbox.getChildren().addAll(hboxOne, detailsLabel);
				vbox.getStyleClass().add("vb");
				mainBox.getChildren().add(vbox);
			}
			scrollPane.setContent(mainBox);
			scrollPane.setId("sid");
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			schedulePane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
