package com.tournament.controllers.tournament;

import java.net.URL;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Player;
import com.tournament.dto.Tournament;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.HBox;
import javafx.scene.layout.TilePane;

public class GeneratedTournamentController implements Initializable {

	private List<List<Player>> playerBucketNew, playerBucketOld;
	@FXML
	private TilePane tilePane;
	List<ToggleButton> toggleButtonList = new ArrayList<ToggleButton>();
	@FXML
	private Label errorLabel;
	@FXML
	private BorderPane tournamentPane;
	@FXML
	private HBox exchangeBox;
	@FXML
	private Button nameTeamBtn;
	ListView<Player> fromPlayer, toPlayer;
	private String tournamentName, fromTime, toTime, numberOfTeams, date;

	public GeneratedTournamentController(List<List<Player>> playerBucket, String tournamentName, String fromTime,
			String toTime, String numberOfTeams, String date) {
		this.playerBucketOld = playerBucket;
		this.playerBucketNew = playerBucket;
		this.fromTime = fromTime;
		this.toTime = toTime;
		this.tournamentName = tournamentName;
		this.numberOfTeams = numberOfTeams;
		this.date = date;
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			generateTeamList(playerBucketOld);
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			tournamentPane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	int ind1 = -1, ind2 = -1;

	public void exchange() {
		exchangeBox.getChildren().clear();
		int count = 0;
		for (ToggleButton tb : toggleButtonList) {
			if (tb.isSelected()) {
				count = count + 1;
			}
		}
		if (count > 2) {
			errorLabel.setText("Select Only Two Teams To Edit");
		} else if (count == 0 || count == 1) {
			errorLabel.setText("Select Two Teams To Edit");
		} else {
			errorLabel.setText("");
			List<ToggleButton> tblst = new ArrayList<ToggleButton>();
			for (ToggleButton tb : toggleButtonList) {
				if (tb.isSelected()) {
					tblst.add(tb);
				}
			}
			fromPlayer = new ListView<Player>(
					FXCollections.observableArrayList((List<Player>) tblst.get(0).getUserData()));
			fromPlayer.setCellFactory(playerListView -> new PlayerListViewCell());
			fromPlayer.setPrefSize(500, 40);
			toPlayer = new ListView<Player>(
					FXCollections.observableArrayList((List<Player>) tblst.get(1).getUserData()));
			toPlayer.setCellFactory(playerListView -> new PlayerListViewCell());
			toPlayer.setPrefSize(500, 40);
			fromPlayer.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
			toPlayer.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
			exchangeBox.getChildren().add(fromPlayer);
			exchangeBox.getChildren().add(toPlayer);
			ind1 = playerBucketOld.indexOf((List<Player>) tblst.get(0).getUserData());
			ind2 = playerBucketOld.indexOf((List<Player>) tblst.get(1).getUserData());
			playerBucketNew.set(ind1, fromPlayer.getItems());
			playerBucketNew.set(ind2, toPlayer.getItems());
		}
	}

	public void moveItemsAB() {
		if (fromPlayer.getSelectionModel().getSelectedItems() != null) {
			List<Player> selectedPlayers = fromPlayer.getSelectionModel().getSelectedItems();
			toPlayer.getItems().addAll(selectedPlayers);
			fromPlayer.getItems().removeAll(selectedPlayers);
		}
		generateTeamList(playerBucketNew);
	}
	public void moveItemsBA() {
		if (toPlayer.getSelectionModel().getSelectedItems() != null) {
			List<Player> selectedPlayers = toPlayer.getSelectionModel().getSelectedItems();
			fromPlayer.getItems().addAll(selectedPlayers);
			toPlayer.getItems().removeAll(selectedPlayers);
		}
		generateTeamList(playerBucketNew);
	}

	public void nameTeamView() {
		try {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Continue Naming");
			alert.setHeaderText("Want to continue with new arrangement");
			Optional<ButtonType> option = alert.showAndWait();
			if (option.get() == ButtonType.OK) {
				showView(playerBucketNew);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void showView(List<List<Player>> playerbucket) {
		try {
			Tournament tournament = new Tournament();
			tournament.setName(tournamentName);
			tournament.setFromTime(generateSqlDate(date, fromTime));
			tournament.setToTime(generateSqlDate(date, toTime));
			Stage stage = (Stage) nameTeamBtn.getScene().getWindow();
			FXMLLoader loader = new FXMLLoader(
					getClass().getResource("/com/tournament/fxml/tournament/NameTeamsView.fxml"));
			loader.setController(new NameViewController(playerbucket, tournament));
			Parent root = loader.load();
			Scene scene = new Scene(root, 1200, 700);
			Stage primaryStage = new Stage();
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private Timestamp generateSqlDate(String date, String time) {
		Timestamp sqlDate = null;
		DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			java.util.Date dt = df1.parse(date + " " + time);
			sqlDate = new Timestamp(dt.getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return sqlDate;
	}

	private void generateTeamList(List<List<Player>> playerBucket) {
		try {
			toggleButtonList.clear();
			tilePane.getChildren().clear();
			for (List<Player> playerList : playerBucket) {
				StringBuilder sbuilder = new StringBuilder();
				for (Player p : playerList) {
					sbuilder.append(p.getId()).append(" ").append(p.getFirstName()).append(" ").append(p.getLastName())
							.append("\n");
				}
				if (sbuilder.toString() != null && !sbuilder.toString().equals("")) {
					ToggleButton tb = new ToggleButton(sbuilder.toString());
					tb.setUserData(playerList);
					tb.getStyleClass().add("toggleButton");
					toggleButtonList.add(tb);
					tilePane.getChildren().add(tb);
				}
			}
			tilePane.setHgap(10);
			tilePane.setVgap(10);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
