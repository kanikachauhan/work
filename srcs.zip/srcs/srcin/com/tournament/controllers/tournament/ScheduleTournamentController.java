package com.tournament.controllers.tournament;

import java.net.URL;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;


import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Match;
import com.tournament.dto.Pitch;
import com.tournament.dto.PitchTime;
import com.tournament.dto.Refree;
import com.tournament.dto.RefreeTime;
import com.tournament.dto.Team;
import com.tournament.dto.Tournament;
import com.tournament.repositories.MatchOperations;
import com.tournament.repositories.PitchOperations;
import com.tournament.repositories.PitchTimeOperations;
import com.tournament.repositories.RefreeOperations;
import com.tournament.repositories.RefreeTimeOperations;
import com.tournament.repositories.TeamOperations;
import com.tournament.repositories.TournamentOperations;
import com.tournament.utils.Constants;
import com.tournament.utils.Utils;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class ScheduleTournamentController implements Initializable {

	@FXML
	private BorderPane schedulePane;
	@FXML
	ComboBox<String> tournamentBox, tournamentType;
	@FXML
	ListView<String> pitchListView, teamListView, refreeListView;
	@FXML
	TextField dateField, fromTimeField, toTimeField, intervalField, lengthField;
	PitchOperations pitchOperations = new PitchOperations();
	TeamOperations teamOperations = new TeamOperations();
	RefreeOperations refreeOperations = new RefreeOperations();
	RefreeTimeOperations refreeTimeOperations = new RefreeTimeOperations();
	PitchTimeOperations pitchTimeOperations = new PitchTimeOperations();
	TournamentOperations tournamentOperations = new TournamentOperations();
	List<Match> matchList = new ArrayList<Match>();
	@FXML
	Label errorLabel;
	@FXML
	Button generateSchedule;
	List<Pitch> pitchList = null;
	List<Team> teamList = null;
	List<Refree> refreeList = null;
	SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");
	SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
	SimpleDateFormat fullTimeFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	Tournament selectedTournament = null;
	List<Tournament> tournamentList = null;
	private HashMap<Integer, ArrayList<Object>> scheduleMap;
	MatchOperations matchOperations = new MatchOperations();

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			scheduleMap = new HashMap<Integer, ArrayList<Object>>();
			pitchList = pitchOperations.list();
			tournamentList = tournamentOperations.list();
			teamList = teamOperations.teamListByTournament(tournamentList.get(0).getId());
			refreeList = refreeOperations.list();
			List<String> pitchNames = pitchList.stream().map(p -> p.getLocation()).collect(Collectors.toList());
			List<String> teamNames = teamList.stream().map(t -> t.getName()).collect(Collectors.toList());
			List<String> refreeNames = refreeList.stream().map(r -> r.getFirstName()).collect(Collectors.toList());
			List<String> tournamentNames = tournamentList.stream().map(t -> t.getName()).collect(Collectors.toList());
			pitchListView.setItems(FXCollections.observableList(pitchNames));
			pitchListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
			teamListView.setItems(FXCollections.observableList(teamNames));
			refreeListView.setItems(FXCollections.observableList(refreeNames));
			refreeListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
			tournamentBox.setItems(FXCollections.observableArrayList(tournamentNames));
			tournamentType.setItems(FXCollections
					.observableArrayList(new ArrayList<String>(Arrays.asList("Knock Out", "Round Robin"))));
			tournamentBox.getSelectionModel().select(0);
			tournamentType.getSelectionModel().select(0);
			if (tournamentBox.getItems().size() > 0) {
				int index = tournamentBox.getSelectionModel().getSelectedIndex();
				selectedTournament = tournamentList.get(index);
				String fromDate = dateFormatter.format(selectedTournament.getFromTime());
				String fromTime = timeFormatter.format(selectedTournament.getFromTime());
				String toTime = timeFormatter.format(selectedTournament.getToTime());
				fromTimeField.setText(fromTime);
				toTimeField.setText(toTime);
				dateField.setText(fromDate);
			}

			tournamentBox.getSelectionModel().selectedItemProperty().addListener((options, oldValue, newValue) -> {
				int index1 = tournamentBox.getSelectionModel().getSelectedIndex();
				teamList = teamOperations.teamListByTournament(tournamentList.get(index1).getId());
				List<String> teamName = teamList.stream().map(t -> t.getName()).collect(Collectors.toList());
				teamListView.setItems(FXCollections.observableList(teamName));
				selectedTournament = tournamentList.get(index1);
				String fromDate1 = dateFormatter.format(selectedTournament.getFromTime());
				String fromTime1 = timeFormatter.format(selectedTournament.getFromTime());
				String toTime1 = timeFormatter.format(selectedTournament.getToTime());
				fromTimeField.setText(fromTime1);
				toTimeField.setText(toTime1);
				dateField.setText(fromDate1);

			});
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			schedulePane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void generateSchedule() {
		try {
			if(lengthField.getText().trim().length()==0) {
				errorLabel.setText("Please length of each match.");
				return;
			}
			if(intervalField.getText().trim().length()==0) {
				errorLabel.setText("Please specify interval between two matches.");
				return;
			}
			Date d1 = fullTimeFormatter.parse(selectedTournament.getFromTime().toString());
			Date d2 = fullTimeFormatter.parse(selectedTournament.getToTime().toString());
			long diff = d2.getTime() - d1.getTime();
			long diffMin = diff / (60 * 1000);
			int numberofmatches = possibleTeams();
			if (numberofmatches == 0) {
				return;
			}
			int intervalLength = Integer.parseInt(lengthField.getText().trim());
			int freeTime = Integer.parseInt(intervalField.getText().trim());
			long duration = (numberofmatches * intervalLength) + ((numberofmatches - 1) * freeTime);
			if (duration > diffMin) {
				errorLabel.setText("Adjust Interval or Length of match");
				return;
			}
			updateTeamMappings(numberofmatches);
			assignTime(d1, d2, freeTime, intervalLength);
			assignRefree();
			assignPitch();
			if (tournamentType.getSelectionModel().getSelectedIndex() == 1) {
				for (Integer i : scheduleMap.keySet()) {
					ArrayList<Object> objectList = scheduleMap.get(i);
					Match match = new Match();
					match.setTeamHome(((Team) (objectList.get(0))).getId());
					match.setTeamAway(((Team) (objectList.get(1))).getId());
					Date dt = (Date) (objectList.get(2));
					Timestamp fromtime = new Timestamp(dt.getTime());
					match.setFromTime(fromtime);
					dt = (Date) objectList.get(3);
					Timestamp totime = new Timestamp(dt.getTime());
					match.setToTime(totime);
					int pitchId = ((Pitch) objectList.get(5)).getId();
					int refreeId = ((Refree) objectList.get(4)).getId();
					match.setRefreeId(refreeId);
					match.setPitch(pitchId);
					match.setTournamentId(selectedTournament.getId());
					matchList.add(match);
					boolean status = matchOperations.add(match);
					PitchTime ptime = new PitchTime();
					ptime.setPitch_id(pitchId);
					ptime.setFromTime(fromtime);
					ptime.setToTime(totime);
					boolean pstatus = pitchTimeOperations.add(ptime);
					RefreeTime rtime = new RefreeTime();
					rtime.setFromTime(fromtime);
					rtime.setToTime(totime);
					rtime.setRefreeId(refreeId);
					boolean rstatus = refreeTimeOperations.add(rtime);
					boolean typeStatus = tournamentOperations.updateTournamentType(tournamentType.getSelectionModel().getSelectedIndex(), selectedTournament.getId());
					if (!status || !rstatus || !pstatus || !typeStatus) {
						errorLabel.setText("Error In generating schedule");
						break;
					}
				}
				newView(false);
			} else {
				for (Integer i : scheduleMap.keySet()) {
					ArrayList<Object> objectList = scheduleMap.get(i);
					Match match = new Match();
					match.setTeamHome((Integer) (objectList.get(0)));
					match.setTeamAway((Integer) (objectList.get(1)));
					match.setRound((Integer) objectList.get(2));
					Date dt = (Date) (objectList.get(3));
					Timestamp fromtime = new Timestamp(dt.getTime());
					match.setFromTime(fromtime);
					dt = (Date) objectList.get(4);
					Timestamp totime = new Timestamp(dt.getTime());
					match.setToTime(totime);
					int refreeid = ((Refree) objectList.get(5)).getId();
					int pitchid = ((Pitch) objectList.get(6)).getId();
					match.setRefreeId(refreeid);
					match.setPitch(pitchid);
					match.setTournamentId(selectedTournament.getId());
					matchList.add(match);
					boolean status = matchOperations.add(match);
					PitchTime ptime = new PitchTime();
					ptime.setPitch_id(pitchid);
					ptime.setFromTime(fromtime);
					ptime.setToTime(totime);
					boolean pstatus = pitchTimeOperations.add(ptime);
					RefreeTime rtime = new RefreeTime();
					rtime.setFromTime(fromtime);
					rtime.setToTime(totime);
					rtime.setRefreeId(refreeid);
					boolean rstatus = refreeTimeOperations.add(rtime);
					boolean typeStatus = tournamentOperations.updateTournamentType(tournamentType.getSelectionModel().getSelectedIndex(), selectedTournament.getId());
					if (!status || !rstatus || !pstatus || !typeStatus) {
						errorLabel.setText("Error In generating schedule");
						break;
					}
				}
				newView(true);
			}
		} catch (Exception ex) {
			errorLabel.setText("Error while generating schedule");
			ex.printStackTrace();
		}
	}

	public void newView(boolean flag) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tournament/fxml/tournament/GeneratedSchedule.fxml"));
			loader.setController(new GeneratedScheduleController(matchList, flag));
			Parent root = loader.load();
			Scene scene = new Scene(root, 1200, 700);
			Constants.stageGenerator.primaryStage.setScene(scene);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	int roundCount = 0;
	/**
	 * delivers the count of possible matches in the tournament based on selection.
	 * @return
	 */
	private int possibleTeams() {
		int count = 0;
		if (tournamentType.getSelectionModel().getSelectedIndex() == 1) {
			int s = teamList.size();
			for (int i = s; i >= 1; i--) {
				count = count + (i - 1);
			}
		} else {
			if (teamList.size() % 2 == 0) {
				int counter = teamList.size();
				while (counter != 1) {
					int rem = counter % 2;
					if (rem == 0) {
						counter = counter / 2;
						count = count + counter;
						roundCount = roundCount + 1;
					} else {
						count = 0;
						errorLabel.setText("Knockout not possible.");
						break;
					}
				}
			}
		}
		return count;
	}
	/**
	 * from team and to team mappings
	 * @param count
	 */
	private void updateTeamMappings(int count) {
		if (tournamentType.getSelectionModel().getSelectedIndex() == 1) {
			int temp = 1;
			Team fromTeam = null, toTeam = null;
			for (int j = 0; j < teamList.size(); j++) {
				fromTeam = teamList.get(j);
				for (int k = j + 1; k < teamList.size(); k++) {
					ArrayList<Object> list = new ArrayList<Object>();
					toTeam = teamList.get(k);
					list.add(fromTeam);
					list.add(toTeam);
					scheduleMap.put(temp, list);
					temp = temp + 1;
				}
			}
		} else {
			int key = 0;
			for (int i = 1; i <= roundCount; i++) {
				int k = (int) (Math.pow(2, i));
				for (int j = 1; j <= k; j = j + 2) {
					ArrayList<Object> objectList = new ArrayList<Object>();
					key = key + 1;
					objectList.add(j);
					objectList.add(j + 1);
					objectList.add(i);
					scheduleMap.put(key, objectList);
				}
			}
		}
	}
	/**
	 * assign time to each match after calculation,
	 * update match with new list having values of from time and to time
	 * @param startDate
	 * @param endDate
	 * @param interval
	 * @param length
	 */
	private void assignTime(Date startDate, Date endDate, int interval, int length) {
		Date newDate = startDate;
		for (Integer i : scheduleMap.keySet()) {
			ArrayList<Object> list = scheduleMap.get(i);
			Date middleDate = newDate;
			newDate = Utils.addDateTime(length, newDate);
			if (newDate.before(endDate)) {
				list.add(middleDate);
				list.add(newDate);
				newDate = Utils.addDateTime(interval, newDate);
			}
			if (newDate.after(endDate)) {
				errorLabel.setText("Cannot generate schedule due to time constraints");
				break;
			}
			scheduleMap.put(i, list);
		}
	}
	/**
	 * refree assignment from refreetime table
	 */
	private void assignRefree() {
		try {
			List<Integer> selectedList = refreeListView.getSelectionModel().getSelectedIndices();
			List<Refree> selectedRefreeList = new ArrayList<Refree>();
			for(int i:selectedList) {
				selectedRefreeList.add(refreeList.get(i));
			}
			for (Integer i : scheduleMap.keySet()) {
				ArrayList<Object> list = scheduleMap.get(i);
				Date startDate = null, endDate = null;
				if (tournamentType.getSelectionModel().getSelectedIndex() == 1) {
					startDate = (Date) list.get(2);
					endDate = (Date) list.get(3);
				} else {
					startDate = (Date) list.get(3);
					endDate = (Date) list.get(4);
				}
				Refree selectedRefree = null;
				for (Refree refree : selectedRefreeList) {
					selectedRefree = getDesiredRefree(refree, startDate, endDate);
					if (selectedRefree != null) {
						break;
					}
				}
				if (selectedRefree == null) {
					errorLabel.setText("Cannot create schedule. No Refree found");
					break;
				}
				list.add(selectedRefree);
				if(selectedRefreeList!=null) {
					selectedRefreeList.remove(selectedRefree);
				}
				if(selectedRefreeList==null||selectedRefreeList.isEmpty()||selectedRefreeList.size()==0) {
					selectedRefreeList = new ArrayList<Refree>();
					for(int temp:selectedList) {
						selectedRefreeList.add(refreeList.get(temp));
					}
				}
				scheduleMap.put(i, list);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private void assignPitch() {
		try {
			List<Integer> selectedList = pitchListView.getSelectionModel().getSelectedIndices();
			List<Pitch> selectedPitchList = new ArrayList<Pitch>();
			for(int i:selectedList) {
				selectedPitchList.add(pitchList.get(i));
			}
			for (Integer i : scheduleMap.keySet()) {
				ArrayList<Object> list = scheduleMap.get(i);
				Date startDate = null, endDate = null;
				if (tournamentType.getSelectionModel().getSelectedIndex() == 1) {
					startDate = (Date) list.get(2);
					endDate = (Date) list.get(3);
				} else {
					startDate = (Date) list.get(3);
					endDate = (Date) list.get(4);
				}
				Pitch selectedPitch = null;
				for (Pitch pitch : selectedPitchList) {
					selectedPitch = getDesiredPitch(pitch, startDate, endDate);
					if (selectedPitch != null) {
						break;
					}
				}
				if (selectedPitch == null) {
					errorLabel.setText("Cannot create schedule. No Refree found");
					break;
				}
				list.add(selectedPitch);
				if(selectedPitchList!=null) {
					selectedPitchList.remove(selectedPitch);
				}
				if(selectedPitchList==null||selectedPitchList.isEmpty()||selectedPitchList.size()==0) {
					selectedPitchList = new ArrayList<Pitch>();
					for(int temp:selectedList) {
						selectedPitchList.add(pitchList.get(temp));
					}
				}
				scheduleMap.put(i, list);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	private Pitch getDesiredPitch(Pitch pitchToCheck, Date startDate, Date endDate) {
		List<PitchTime> pitchTimeList = pitchTimeOperations.getList(pitchToCheck.getId());
		if (pitchTimeList == null || pitchTimeList.size() == 0) {
			return pitchToCheck;
		} else {
			boolean flag = false;
			for (PitchTime time : pitchTimeList) {
				if (time.getFromTime().after(startDate) && time.getFromTime().before(endDate)) {
				} else if (time.getToTime().after(startDate) && time.getToTime().before(endDate)) {
				} else {
					flag = true;
					break;
				}
			}
			if (flag) {
				return pitchToCheck;
			} else {
				return null;
			}
		}
	}

	private Refree getDesiredRefree(Refree refreeToCheck, Date startDate, Date endDate) {
		List<RefreeTime> refreeTimeList = refreeTimeOperations.getList(refreeToCheck.getId());
		if (refreeTimeList == null || refreeTimeList.size() == 0) {
			return refreeToCheck;
		} else {
			boolean flag = false;
			for (RefreeTime time : refreeTimeList) {
				if (time.getFromTime().after(startDate) && time.getFromTime().before(endDate)) {
				} else if (time.getToTime().after(startDate) && time.getToTime().before(endDate)) {
				} else {
					flag = true;
					break;
				}
			}
			if (flag) {
				return refreeToCheck;
			} else {
				return null;
			}
		}
	}
}
