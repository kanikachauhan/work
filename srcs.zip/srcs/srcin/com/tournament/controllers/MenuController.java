package com.tournament.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import com.tournament.utils.Constants;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;

public class MenuController implements Initializable {

	@FXML
	private MenuItem addPlayer, listPlayer, deletePlayer, updatePlayer, addPitch, listPitch, deletePitch, updatePitch,
			updateRefree, deleteRefree, listRefree, addRefree, createTournament, addAward, listAward, deleteAward,
			addGoal, listGoal, deleteGoal, exit, home, listTournament, updateTeam, listTeam, deleteTeam, listMatch,
			updateMatch;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		listMatch.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/match/ListMatch.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		updateMatch.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/match/UpdateMatch.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		listTournament.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader.load(
						getClass().getClassLoader().getResource("com/tournament/fxml/tournament/ListTournament.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		updateTeam.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/team/UpdateTeam.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		listTeam.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/team/ListTeam.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		deleteTeam.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/team/DeleteTeam.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		home.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/Main.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		exit.setOnAction(event -> {
			BorderPane root;
			System.exit(1);
		});
		addPlayer.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/player/AddPlayer.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		listPlayer.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/player/ListPlayer.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		deletePlayer.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/player/DeletePlayer.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		updatePlayer.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/player/UpdatePlayer.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		addPitch.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/pitch/AddPitch.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		listPitch.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/pitch/ListPitch.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		deletePitch.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/pitch/DeletePitch.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		updatePitch.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/pitch/UpdatePitch.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		addRefree.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/refree/AddRefree.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		listRefree.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/refree/ListRefree.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		updateRefree.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/refree/UpdateRefree.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		deleteRefree.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/refree/DeleteRefree.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		createTournament.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader()
						.getResource("com/tournament/fxml/tournament/CreateTournament.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		addAward.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/award/CreateAward.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		listAward.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/award/ListAward.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		deleteAward.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/award/DeleteAward.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		addGoal.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/goal/AddGoal.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		listGoal.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/goal/ListGoal.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		deleteGoal.setOnAction(event -> {
			BorderPane root;
			try {
				root = FXMLLoader
						.load(getClass().getClassLoader().getResource("com/tournament/fxml/goal/DeleteGoal.fxml"));
				Scene scene = new Scene(root, 1200, 700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}

}
