package com.tournament.controllers.player;

import java.net.URL;
import java.util.ResourceBundle;

import com.tournament.dto.Player;
import com.tournament.repositories.PlayerOperations;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class DeletePlayerController implements Initializable {

	@FXML
	private HBox deletePlayerBox;
	@FXML
	private BorderPane borderPane;
	@FXML
	private Button deleteButton;
	@FXML
	private Label errorLabel;
	private TableView<Player> table = new TableView<Player>();
	TableColumn<Player, Integer> idColumn = new TableColumn<Player, Integer>("Id");
	TableColumn<Player, String> firstNameColumn = new TableColumn<Player, String>("First Name");
	TableColumn<Player, String> lastNameColumn = new TableColumn<Player, String>("Last Name");
	TableColumn<Player, Character> genderColumn = new TableColumn<Player, Character>("Gender");
	TableColumn<Player, String> emailColumn = new TableColumn<Player, String>("Email");
	TableColumn<Player, String> positionColumn = new TableColumn<Player, String>("Position");
	TableColumn<Player, Double> defendingColumn = new TableColumn<Player, Double>("Defending");
	TableColumn<Player, Double> attackingColumn = new TableColumn<Player, Double>("Attacking");
	TableColumn<Player, Double> speedColumn = new TableColumn<Player, Double>("Speed");
	TableColumn<Player, Double> physicalColumn = new TableColumn<Player, Double>("Physical");
	TableColumn<Player, Double> shootingColumn = new TableColumn<Player, Double>("Shooting");
	PlayerOperations playerOperations = new PlayerOperations();
	Player selectedplayer = null;

	@FXML
	private VBox vbox;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			idColumn.setCellValueFactory(new PropertyValueFactory<Player, Integer>("id"));
			firstNameColumn.setCellValueFactory(new PropertyValueFactory<Player, String>("firstName"));
			firstNameColumn.setResizable(true);
			lastNameColumn.setCellValueFactory(new PropertyValueFactory<Player, String>("lastName"));
			lastNameColumn.setResizable(true);
			genderColumn.setCellValueFactory(new PropertyValueFactory<Player, Character>("gender"));
			genderColumn.setResizable(true);
			emailColumn.setCellValueFactory(new PropertyValueFactory<Player, String>("email"));
			emailColumn.setResizable(true);
			positionColumn.setCellValueFactory(new PropertyValueFactory<Player, String>("position"));
			positionColumn.setResizable(true);
			defendingColumn.setCellValueFactory(new PropertyValueFactory<Player, Double>("defending"));
			defendingColumn.setResizable(true);
			attackingColumn.setCellValueFactory(new PropertyValueFactory<Player, Double>("attacking"));
			attackingColumn.setResizable(true);
			speedColumn.setCellValueFactory(new PropertyValueFactory<Player, Double>("speed"));
			speedColumn.setResizable(true);
			physicalColumn.setCellValueFactory(new PropertyValueFactory<Player, Double>("physical"));
			physicalColumn.setResizable(true);
			shootingColumn.setCellValueFactory(new PropertyValueFactory<Player, Double>("shooting"));
			shootingColumn.setResizable(true);
			table.setItems(FXCollections.observableList(playerOperations.list()));
			table.getColumns().addAll(idColumn, firstNameColumn, lastNameColumn, genderColumn, emailColumn,
					positionColumn, defendingColumn, attackingColumn, speedColumn, physicalColumn, shootingColumn);
			table.setMaxWidth(700);
			table.setMaxHeight(600);
			table.setVisible(true);
			deletePlayerBox.getChildren().add(table);
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			borderPane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void deletePlayer() {
		int index = table.getSelectionModel().getSelectedIndex();
		if (index == -1) {
			errorLabel.setText("Select One Value For Deletion");
			return;
		}
		selectedplayer = table.getItems().get(index);
		boolean deletionStatus = playerOperations.delete(selectedplayer.getId());
		if (deletionStatus) {
			table.getItems().remove(index);
		}
	}
}
