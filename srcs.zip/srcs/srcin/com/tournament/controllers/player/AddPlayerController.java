package com.tournament.controllers.player;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.dto.Player;
import com.tournament.repositories.PlayerOperations;
import com.tournament.utils.Utils;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class AddPlayerController implements Initializable {

	@FXML
	private ChoiceBox<Character> genderBox;
	@FXML
	private ChoiceBox<String> positionBox;
	@FXML
	private Slider defendingSlider, attackingSlider, shootingSlider, speedSlider, physicalSlider;
	@FXML
	private TextField lastName, firstName, contactNumber, email;
	@FXML
	private TextArea address;
	@FXML
	private BorderPane borderPane;
	@FXML
	private Label errorLabel;
	List<Character> genderList = new ArrayList<Character>();
	List<String> positionList = new ArrayList<String>();
	PlayerOperations playerOperations = new PlayerOperations();

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			genderList.add('M');
			genderList.add('F');
			positionList.add("GK");
			positionList.add("DF");
			positionList.add("MF");
			positionList.add("FW");
			genderBox.setItems(FXCollections.observableList(genderList));
			genderBox.setValue(genderList.get(0));
			positionBox.setItems(FXCollections.observableList(positionList));
			positionBox.setValue(positionList.get(0));
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			borderPane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void savePlayer() {
		try {
			Player player = new Player();

			if (!Utils.validateRegex("^\\w{1,45}$", firstName.getText())) {
				errorLabel.setText("FirstName should have length min:1 and max:45");
				return;
			}
			if (!Utils.validateRegex("^\\w{1,45}$", lastName.getText())) {
				errorLabel.setText("LastName should have length min:1 and max:45");
				return;
			}
			if (!Utils.validateRegex("^(.+)@(.+)$", email.getText())) {
				errorLabel.setText("Invalid Email");
				return;
			}
			if (address.getText().length() < 5 || address.getText().length() > 100) {
				errorLabel.setText("Address should have length min:5 and max:100");
				return;
			}
			if (!Utils.validateRegex("\\d{7,20}", contactNumber.getText())) {
				errorLabel.setText("Contact Number should have numbers min 7 and max length 20");
				return;
			}
			player.setAddress(address.getText());
			player.setAttacking(Utils.roundToTwoPlaces(attackingSlider.getValue()));
			player.setContactNumber(contactNumber.getText());
			player.setDefending(Utils.roundToTwoPlaces(defendingSlider.getValue()));
			player.setEmail(email.getText());
			player.setFirstName(firstName.getText());
			player.setGender(genderBox.getValue());
			player.setLastName(lastName.getText());
			player.setPhysical(Utils.roundToTwoPlaces(physicalSlider.getValue()));
			player.setPosition(positionBox.getValue());
			player.setShooting(Utils.roundToTwoPlaces(shootingSlider.getValue()));
			player.setSpeed(Utils.roundToTwoPlaces(speedSlider.getValue()));
			playerOperations.add(player);
			errorLabel.setText("Saved Successfully!!");
		} catch (Exception e) {
			errorLabel.setText("Error While Saving Details");
		}
	}

}
