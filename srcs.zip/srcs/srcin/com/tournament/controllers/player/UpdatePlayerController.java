package com.tournament.controllers.player;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.dto.Player;
import com.tournament.repositories.PlayerOperations;
import com.tournament.utils.Utils;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class UpdatePlayerController implements Initializable {

	@FXML
	private ChoiceBox<Character> genderBox;
	@FXML
	private ChoiceBox<String> positionBox;
	@FXML
	private Slider defendingSlider, attackingSlider, shootingSlider, speedSlider, physicalSlider;
	@FXML
	private TextField lastName, firstName, contactNumber, email;
	@FXML
	private TextArea address;
	@FXML
	private BorderPane borderPane;
	@FXML
	private Label errorlabel;
	Player selectedplayer = null;
	List<Character> genderList = new ArrayList<Character>();
	List<String> positionList = new ArrayList<String>();
	private TableView<Player> table = new TableView<Player>();
	TableColumn<Player, Integer> idColumn = new TableColumn<Player, Integer>("Id");
	TableColumn<Player, String> firstNameColumn = new TableColumn<Player, String>("First Name");
	TableColumn<Player, String> lastNameColumn = new TableColumn<Player, String>("Last Name");
	TableColumn<Player, Character> genderColumn = new TableColumn<Player, Character>("Gender");
	TableColumn<Player, String> emailColumn = new TableColumn<Player, String>("Email");
	TableColumn<Player, String> positionColumn = new TableColumn<Player, String>("Position");
	TableColumn<Player, Double> defendingColumn = new TableColumn<Player, Double>("Defending");
	TableColumn<Player, Double> attackingColumn = new TableColumn<Player, Double>("Attacking");
	TableColumn<Player, Double> speedColumn = new TableColumn<Player, Double>("Speed");
	TableColumn<Player, Double> physicalColumn = new TableColumn<Player, Double>("Physical");
	TableColumn<Player, Double> shootingColumn = new TableColumn<Player, Double>("Shooting");
	TableColumn<Player, String> contactColumn = new TableColumn<Player, String>("contactNumber");
	TableColumn<Player, String> addressColumn = new TableColumn<Player, String>("address");
	PlayerOperations playerOperations = new PlayerOperations();
	List<Player> playerList = null;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			playerList = FXCollections.observableList(playerOperations.list());
			genderList.add('M');
			genderList.add('F');
			positionList.add("GK");
			positionList.add("DF");
			positionList.add("MF");
			positionList.add("FW");
			genderBox.setItems(FXCollections.observableList(genderList));
			genderBox.setValue(genderList.get(0));
			positionBox.setItems(FXCollections.observableList(positionList));
			positionBox.setValue(positionList.get(0));
			idColumn.setCellValueFactory(new PropertyValueFactory<Player, Integer>("id"));
			firstNameColumn.setCellValueFactory(new PropertyValueFactory<Player, String>("firstName"));
			firstNameColumn.setResizable(true);
			lastNameColumn.setCellValueFactory(new PropertyValueFactory<Player, String>("lastName"));
			lastNameColumn.setResizable(true);
			genderColumn.setCellValueFactory(new PropertyValueFactory<Player, Character>("gender"));
			genderColumn.setResizable(true);
			emailColumn.setCellValueFactory(new PropertyValueFactory<Player, String>("email"));
			emailColumn.setResizable(true);
			positionColumn.setCellValueFactory(new PropertyValueFactory<Player, String>("position"));
			positionColumn.setResizable(true);
			defendingColumn.setCellValueFactory(new PropertyValueFactory<Player, Double>("defending"));
			defendingColumn.setResizable(true);
			attackingColumn.setCellValueFactory(new PropertyValueFactory<Player, Double>("attacking"));
			attackingColumn.setResizable(true);
			speedColumn.setCellValueFactory(new PropertyValueFactory<Player, Double>("speed"));
			speedColumn.setResizable(true);
			physicalColumn.setCellValueFactory(new PropertyValueFactory<Player, Double>("physical"));
			physicalColumn.setResizable(true);
			shootingColumn.setCellValueFactory(new PropertyValueFactory<Player, Double>("shooting"));
			shootingColumn.setResizable(true);
			contactColumn.setCellValueFactory(new PropertyValueFactory<Player, String>("contactNumber"));
			contactColumn.setResizable(true);
			addressColumn.setCellValueFactory(new PropertyValueFactory<Player, String>("address"));
			addressColumn.setResizable(true);
			table.setItems(FXCollections.observableList(playerList));
			table.getColumns().addAll(idColumn, firstNameColumn, lastNameColumn, genderColumn, emailColumn,
					positionColumn, defendingColumn, attackingColumn, speedColumn, physicalColumn, shootingColumn,
					contactColumn, addressColumn);
			table.setMaxWidth(500);
			table.setMaxHeight(500);
			table.setVisible(true);
			borderPane.setLeft(table);
			table.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Player>() {

				@Override
				public void changed(ObservableValue<? extends Player> observable, Player oldValue, Player newValue) {
					int index = table.getSelectionModel().getSelectedIndex();
					if (index != -1) {
						selectedplayer = table.getItems().get(index);
						firstName.setText(selectedplayer.getFirstName());
						lastName.setText(selectedplayer.getLastName());
						address.setText(selectedplayer.getAddress());
						defendingSlider.setValue(selectedplayer.getDefending());
						attackingSlider.setValue(selectedplayer.getAttacking());
						shootingSlider.setValue(selectedplayer.getShooting());
						physicalSlider.setValue(selectedplayer.getPhysical());
						speedSlider.setValue(selectedplayer.getSpeed());
						email.setText(selectedplayer.getEmail());
						contactNumber.setText(selectedplayer.getContactNumber());
						genderBox.setValue(selectedplayer.getGender());
						positionBox.setValue(selectedplayer.getPosition());
					}
				}
			});
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			borderPane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void updatePlayer() {
		Player player = new Player();
		int index = table.getSelectionModel().getSelectedIndex();
		if (index == -1) {
			errorlabel.setText("Select One Value For Update");
			return;
		}
		if (!Utils.validateRegex("^\\w{1,45}$", firstName.getText())) {
			errorlabel.setText("FirstName should have length min:1 and max:45");
			return;
		}
		if (!Utils.validateRegex("^\\w{1,45}$", lastName.getText())) {
			errorlabel.setText("LastName should have length min:1 and max:45");
			return;
		}
		if (!Utils.validateRegex("^(.+)@(.+)$", email.getText())) {
			errorlabel.setText("Invalid Email");
			return;
		}
		if (address.getText().length() < 5 || address.getText().length() > 100) {
			errorlabel.setText("Address should have length min:5 and max:100");
			return;
		}
		if (!Utils.validateRegex("\\d{1,20}", contactNumber.getText())) {
			errorlabel.setText("Contact Number should have numbers  min 7 and max length 20");
			return;
		}
		player.setAddress(address.getText());
		player.setAttacking(Utils.roundToTwoPlaces(attackingSlider.getValue()));
		player.setContactNumber(contactNumber.getText());
		player.setDefending(Utils.roundToTwoPlaces(defendingSlider.getValue()));
		player.setEmail(email.getText());
		player.setFirstName(firstName.getText());
		player.setGender(genderBox.getValue());
		player.setLastName(lastName.getText());
		player.setPhysical(Utils.roundToTwoPlaces(physicalSlider.getValue()));
		player.setPosition(positionBox.getValue());
		player.setShooting(Utils.roundToTwoPlaces(shootingSlider.getValue()));
		player.setSpeed(speedSlider.getValue());
		player.setId(selectedplayer.getId());
		if (playerOperations.update(player)) {
			playerList.set(index, player);
			table.setItems(FXCollections.observableArrayList(playerList));
			errorlabel.setText("Update done");
		}
	}
}
