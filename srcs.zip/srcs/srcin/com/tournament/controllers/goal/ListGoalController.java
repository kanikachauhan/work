package com.tournament.controllers.goal;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Goal;
import com.tournament.repositories.GoalOperations;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class ListGoalController implements Initializable {

	@FXML
	private VBox vbox;
	TableView<Goal> table = new TableView<Goal>();
	TableColumn<Goal, Integer> idCol = new TableColumn<Goal, Integer>("Id");
	TableColumn<Goal, String> playerCol = new TableColumn<Goal, String>("Player Name");
	TableColumn<Goal, String> teamHomeCol = new TableColumn<Goal,String>("Team Home");
	TableColumn<Goal, String> teamAwayCol = new TableColumn<Goal,String>("Team Away");
	TableColumn<Goal, String> typeCol = new TableColumn<Goal, String>("Type");
	GoalOperations goalOperations = new GoalOperations();
	List<Goal> goals = null;
	@FXML
	BorderPane goalPane;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			goals = goalOperations.list();
			idCol.setCellValueFactory(new PropertyValueFactory<Goal, Integer>("id"));
			idCol.setResizable(true);
			playerCol.setCellValueFactory(new PropertyValueFactory<Goal, String>("playerName"));
			playerCol.setResizable(true);
			teamHomeCol.setCellValueFactory(new PropertyValueFactory<Goal, String>("teamHome"));
			teamHomeCol.setResizable(true);
			teamAwayCol.setCellValueFactory(new PropertyValueFactory<Goal, String>("teamAway"));
			teamAwayCol.setResizable(true);
			typeCol.setCellValueFactory(new PropertyValueFactory<Goal, String>("type"));
			typeCol.setResizable(true);
			table.getColumns().addAll(idCol, playerCol, teamHomeCol,teamAwayCol, typeCol);
			table.setItems(FXCollections.observableList(goals));
			table.setMaxWidth(400);
			table.setMaxHeight(600);
			table.setVisible(true);
			vbox.getChildren().add(table);
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			goalPane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
