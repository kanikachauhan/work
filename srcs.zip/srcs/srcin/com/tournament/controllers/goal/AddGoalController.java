package com.tournament.controllers.goal;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Goal;
import com.tournament.dto.Match;
import com.tournament.dto.Player;
import com.tournament.dto.Tournament;
import com.tournament.repositories.GoalOperations;
import com.tournament.repositories.MatchOperations;
import com.tournament.repositories.PlayerOperations;
import com.tournament.repositories.TournamentOperations;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class AddGoalController implements Initializable {

	PlayerOperations playerOperations = new PlayerOperations();
	MatchOperations matchOperations = new MatchOperations();
	TournamentOperations tournamentOperations = new TournamentOperations();
	@FXML
	ComboBox playerBox, typeBox, matchBox;
	List<Player> playerList = null;
	List<Tournament> tournamentList = null;
	List<Match> matchList = null;
	@FXML
	Label errorLabel;
	GoalOperations goalOperations = new GoalOperations();
	@FXML
	BorderPane goalPane;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			playerList = playerOperations.list();
			tournamentList = tournamentOperations.list();
			matchList = matchOperations.list();
			List<String> playerNames = playerList.stream().map(p -> p.getFirstName()).collect(Collectors.toList());
			List<String> types = new ArrayList();
			types.add("Normal");
			types.add("Own Goal");
			types.add("Penalty");
			typeBox.setItems(FXCollections.observableArrayList(types));
			typeBox.setValue(typeBox.getItems().get(0));
			List<Integer> matchIds = matchList.stream().map(t -> t.getId()).collect(Collectors.toList());
			if (playerNames != null && playerNames.size() > 0) {
				playerBox.setItems(FXCollections.observableArrayList(playerNames));
				playerBox.setValue(playerBox.getItems().get(0));
			}
			if (matchIds != null && matchIds.size() > 0) {
				matchBox.setItems(FXCollections.observableArrayList(matchIds));
				matchBox.setValue(matchBox.getItems().get(0));
			}
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			goalPane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void saveGoal() {
		Goal goal = new Goal();
		int mind = matchBox.getSelectionModel().getSelectedIndex();
		int pind = playerBox.getSelectionModel().getSelectedIndex();
		goal.setMatch(matchList.get(mind).getId());
		goal.setPlayer(playerList.get(pind).getId());
		goal.setType((String) typeBox.getSelectionModel().getSelectedItem());
		boolean status = goalOperations.add(goal);
		if (status) {
			errorLabel.setText("Values Added");
		} else {
			errorLabel.setText("Error In Addition");
		}
	}
}
