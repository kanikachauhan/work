package com.tournament.controllers.pitch;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Pitch;
import com.tournament.repositories.PitchOperations;
import com.tournament.utils.Constants;
import com.tournament.utils.Utils;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class AddPitchController implements Initializable {

	@FXML
	private TextField location;
	PitchOperations pitchOperations = new PitchOperations();
	@FXML
	private Label errorLabel;
	@FXML
	private BorderPane pitchPane;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			pitchPane.setTop(root);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}

	public void savePitch() {
		try {
			Pitch pitch = new Pitch();
			if (!Utils.validateRegex("^\\w{1,75}$", location.getText())) {
				errorLabel.setText("Location should have length min:1 and max:75");
				return;
			}
			pitch.setLocation(location.getText());
			pitchOperations.add(pitch);
			errorLabel.setText("Values Saved");
		} catch (Exception e) {
			errorLabel.setText("Error in saving");
		}
	}
}
