package com.tournament.controllers.pitch;

import java.net.URL;
import java.sql.Timestamp;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.dto.PitchTime;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class GetPitchScheduleController implements Initializable{

	private List<PitchTime> pitchTimeList;
	@FXML
	BorderPane borderPane;
	@FXML
	Button closeBtn;
	TableView<PitchTime> table = new TableView<PitchTime>();
	TableColumn<PitchTime,Timestamp> one = new TableColumn<PitchTime,Timestamp>("From Time");
	TableColumn<PitchTime,Timestamp> two = new TableColumn<PitchTime,Timestamp>("To Time");
	public GetPitchScheduleController(List<PitchTime> pitchTimeList) {
		this.pitchTimeList = pitchTimeList;
	}
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		one.setCellValueFactory(new PropertyValueFactory<PitchTime,Timestamp>("fromTime"));
		one.setResizable(true);
		two.setCellValueFactory(new PropertyValueFactory<PitchTime,Timestamp>("toTime"));
		two.setResizable(true);
		table.getColumns().addAll(one,two);
		table.setMaxWidth(150);
		table.setMaxHeight(350);
		table.setEditable(true);
		table.setVisible(true);
		table.setItems(FXCollections.observableList(pitchTimeList));
		borderPane.setCenter(table);
	}
	
	public void close() {
		Stage stage = (Stage) closeBtn.getScene().getWindow();
	    stage.close();
	}
}
