package com.tournament.controllers.pitch;

import java.net.URL;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ResourceBundle;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Pitch;
import com.tournament.repositories.PitchOperations;
import com.tournament.utils.Utils;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class UpdatePitchController implements Initializable {

	@FXML
	private BorderPane borderPane;
	private TableView<Pitch> table = new TableView<Pitch>();
	private TableColumn<Pitch, Integer> idColumn = new TableColumn<Pitch, Integer>("id");
	private TableColumn<Pitch, String> locationColumn = new TableColumn<Pitch, String>("location");
	PitchOperations pitchOperations = new PitchOperations();

	@FXML
	private TextField locationField, toTimeField, fromTimeField;
	@FXML
	private Label errorLabel;
	Pitch selectedPitch = null;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			idColumn.setCellValueFactory(new PropertyValueFactory<Pitch, Integer>("id"));
			locationColumn.setCellValueFactory(new PropertyValueFactory<Pitch, String>("location"));
			locationColumn.setResizable(true);
			table.setItems(FXCollections.observableList(pitchOperations.list()));
			table.getColumns().addAll(idColumn, locationColumn);
			table.setMaxWidth(200);
			table.setMaxHeight(400);
			table.setEditable(true);
			table.setVisible(true);
			borderPane.setLeft(table);
			table.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Pitch>() {
				@Override
				public void changed(ObservableValue<? extends Pitch> observable, Pitch oldValue, Pitch newValue) {
					int index = table.getSelectionModel().getSelectedIndex();
					if (index == -1) {
						errorLabel.setText("Select One Value For Update");
						return;
					}
					selectedPitch = table.getItems().get(index);
					locationField.setText(selectedPitch.getLocation());

				}
			});
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			borderPane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void updatePitch() {
		try {
			Pitch pitch = new Pitch();
			int index = table.getSelectionModel().getSelectedIndex();
			if (index == -1) {
				errorLabel.setText("Select One Value For Update");
				return;
			}
			if (!Utils.validateRegex("^\\w{1,75}$", locationField.getText())) {
				errorLabel.setText("Location should have length min:1 and max:75");
				return;
			}

			pitch.setId(selectedPitch.getId());
			pitch.setLocation(locationField.getText());
			pitchOperations.update(pitch);
			errorLabel.setText("Values Updated");
		} catch (Exception e) {
			errorLabel.setText("Error In Update");
		}
	}
}
