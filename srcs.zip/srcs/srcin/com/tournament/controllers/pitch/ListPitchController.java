package com.tournament.controllers.pitch;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Pitch;
import com.tournament.dto.PitchTime;
import com.tournament.repositories.PitchOperations;
import com.tournament.repositories.PitchTimeOperations;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ListPitchController implements Initializable {

	@FXML
	private BorderPane borderPane;
	@FXML
	VBox vbox;
	private TableView<Pitch> table = new TableView<Pitch>();
	private TableColumn<Pitch, Integer> idColumn = new TableColumn<Pitch, Integer>("id");
	private TableColumn<Pitch, String> locationColumn = new TableColumn<Pitch, String>("location");
	PitchOperations pitchOperations = new PitchOperations();
	PitchTimeOperations pitchTimeOperations = new PitchTimeOperations();
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			idColumn.setCellValueFactory(new PropertyValueFactory<Pitch, Integer>("id"));
			locationColumn.setCellValueFactory(new PropertyValueFactory<Pitch, String>("location"));
			locationColumn.setResizable(true);
			table.setItems(FXCollections.observableList(pitchOperations.list()));
			table.getColumns().addAll(idColumn, locationColumn);
			table.setMaxWidth(150);
			table.setMaxHeight(400);
			table.setEditable(true);
			table.setVisible(true);
			table.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Pitch>() {
				@Override
				public void changed(ObservableValue<? extends Pitch> observable, Pitch oldValue, Pitch newValue) {
					int index = table.getSelectionModel().getSelectedIndex();
					List<Pitch> allPitch = pitchOperations.list();
					Pitch selectedPitch = allPitch.get(index);
					List<PitchTime> allPitchTime = pitchTimeOperations.getList(selectedPitch.getId());
					refreeScheduleView(allPitchTime);
				}

			});
			vbox.getChildren().add(table);
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			borderPane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void refreeScheduleView(List<PitchTime> pitchTimeList) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/tournament/fxml/pitch/GetPitchSchedule.fxml"));
			loader.setController(new GetPitchScheduleController(pitchTimeList));
			Parent root = loader.load();
			Scene scene = new Scene(root, 200, 300);
			Stage primaryStage = new Stage();
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
