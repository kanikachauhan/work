package com.tournament.controllers.pitch;

import java.net.URL;
import java.util.ResourceBundle;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Pitch;
import com.tournament.repositories.PitchOperations;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

public class DeletePitchController implements Initializable {

	@FXML
	private BorderPane borderPane;
	private TableView<Pitch> table = new TableView<Pitch>();
	private TableColumn<Pitch, Integer> idColumn = new TableColumn<Pitch, Integer>("id");
	private TableColumn<Pitch, String> locationColumn = new TableColumn<Pitch, String>("location");
	PitchOperations pitchOperations = new PitchOperations();
	Pitch selectedPitch = null;

	@FXML
	private HBox resultBox;
	@FXML
	private Label errorLabel;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			idColumn.setCellValueFactory(new PropertyValueFactory<Pitch, Integer>("id"));
			locationColumn.setCellValueFactory(new PropertyValueFactory<Pitch, String>("location"));
			locationColumn.setResizable(true);
			table.setItems(FXCollections.observableList(pitchOperations.list()));
			table.getColumns().addAll(idColumn, locationColumn);
			table.setMaxWidth(150);
			table.setMaxHeight(400);
			table.setEditable(true);
			table.setVisible(true);
			resultBox.getChildren().add(table);
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			borderPane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void deletePitch() {
		int index = table.getSelectionModel().getSelectedIndex();
		if (index == -1) {
			errorLabel.setText("Select One Value For Deletion");
			return;
		}
		selectedPitch = table.getItems().get(index);
		boolean deletionStatus = pitchOperations.delete(selectedPitch.getId());
		if (deletionStatus) {
			table.getItems().remove(index);
		}
	}

}
