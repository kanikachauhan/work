package com.tournament.controllers.award;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import com.tournament.dto.Player;
import com.tournament.dto.Tournament;
import com.tournament.repositories.AwardOperations;
import com.tournament.repositories.PlayerOperations;
import com.tournament.repositories.TournamentOperations;
import com.tournament.utils.Constants;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;

public class AddAwardController  implements Initializable {
	
	@FXML
	private MenuItem addPlayer,listPlayer,deletePlayer,updatePlayer,
	addPitch,listPitch,deletePitch,updatePitch,
	updateRefree,deleteRefree,listRefree,addRefree,
	createTournament,addAward,listAward,deleteAward,addGoal,listGoal,deleteGoal,exit,home
	,listTournament,updateTeam,listTeam,deleteTeam;
	@FXML
	Label errorLabel;
	@FXML
	ComboBox tournamentBox,playerBox;
	@FXML
	Button saveBtn;
	@FXML
	TextField awardNameField;
	PlayerOperations playerOperations = new PlayerOperations();
	TournamentOperations tournamentOperations = new TournamentOperations();
	AwardOperations awardOperations = new AwardOperations();
	List<Player> playerList = null;
	List<Tournament> tournamentList = null;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		menuControls();
		playerList = playerOperations.list();
		tournamentList = tournamentOperations.list();
		List<String> nameListOne = playerList.stream().map(p->p.getFirstName()).collect(Collectors.toList());
		List<String> nameListTwo = tournamentList.stream().map(t->t.getName()).collect(Collectors.toList());
		tournamentBox.setItems(FXCollections.observableArrayList(nameListOne));
		playerBox.setItems(FXCollections.observableArrayList(nameListTwo));
		tournamentBox.getSelectionModel().select(0);
		playerBox.getSelectionModel().select(0);
	}
	
	public void saveAward() {
		try {
			int index1 = playerBox.getSelectionModel().getSelectedIndex();
			int index2 = tournamentBox.getSelectionModel().getSelectedIndex();
			Player selectedPlayer = playerList.get(index2);
			Tournament selecTournament = tournamentList.get(index1);
			if(awardOperations.createAward(selecTournament, selectedPlayer, awardNameField.getText())) {
				errorLabel.setText("Value Saved");
			}
		}catch(Exception ex) {
			errorLabel.setText("Error while saving award.");
			ex.printStackTrace();
		}
	}
	private void menuControls() {
		listTournament.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/tournament/ListTournament.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		updateTeam.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/team/UpdateTeam.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		listTeam.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/team/ListTeam.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		deleteTeam.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/team/DeleteTeam.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		home.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/Main.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		exit.setOnAction(event->{
			BorderPane root;
			System.exit(1);
		});
		addPlayer.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/player/AddPlayer.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		listPlayer.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/player/ListPlayer.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		deletePlayer.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/player/DeletePlayer.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		updatePlayer.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/player/UpdatePlayer.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		addPitch.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/pitch/AddPitch.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		listPitch.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/pitch/ListPitch.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		deletePitch.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/pitch/DeletePitch.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		updatePitch.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/pitch/UpdatePitch.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		addRefree.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/refree/AddRefree.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		listRefree.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/refree/ListRefree.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		updateRefree.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/refree/UpdateRefree.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		deleteRefree.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/refree/DeleteRefree.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		createTournament.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/tournament/CreateTournament.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		addAward.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/award/CreateAward.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		listAward.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/award/ListAward.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		deleteAward.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/award/DeleteAward.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		addGoal.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/goal/AddGoal.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		listGoal.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/goal/ListGoal.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
		deleteGoal.setOnAction(event->{
			BorderPane root;
			try {
				root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/goal/DeleteGoal.fxml"));
				Scene scene = new Scene(root,1200,700);
				Constants.stageGenerator.primaryStage.setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
		});

	}

}
