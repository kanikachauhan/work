package com.tournament.controllers.award;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.utils.Constants;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Award;
import com.tournament.repositories.AwardOperations;

public class ListAwardController implements Initializable {

	AwardOperations awardOperations = new AwardOperations();

	private List<Award> awardList = null;
	TableView<Award> table = new TableView<Award>();
	TableColumn<Award, Integer> idCol = new TableColumn<Award, Integer>("Id");
	TableColumn<Award, String> playerCol = new TableColumn<Award, String>("Player");
	TableColumn<Award, String> nameCol = new TableColumn<Award, String>("Name");
	TableColumn<Award, String> tournamentCol = new TableColumn<Award, String>("Tournament");
	@FXML
	VBox vbox;
	@FXML
	BorderPane awardPane;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			awardList = awardOperations.list();
			idCol.setCellValueFactory(new PropertyValueFactory<Award, Integer>("id"));
			idCol.setResizable(true);
			playerCol.setCellValueFactory(new PropertyValueFactory<Award, String>("playerName"));
			playerCol.setResizable(true);
			tournamentCol.setCellValueFactory(new PropertyValueFactory<Award, String>("tournamentName"));
			tournamentCol.setResizable(true);
			nameCol.setCellValueFactory(new PropertyValueFactory<Award, String>("name"));
			nameCol.setResizable(true);
			table.getColumns().addAll(idCol, playerCol, tournamentCol, nameCol);
			table.setItems(FXCollections.observableList(awardList));
			table.setMaxWidth(250);
			table.setMaxHeight(600);
			table.setVisible(true);
			table.setItems(FXCollections.observableArrayList(awardList));
			vbox.getChildren().add(table);
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			awardPane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
