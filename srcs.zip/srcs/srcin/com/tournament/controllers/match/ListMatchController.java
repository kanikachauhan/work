package com.tournament.controllers.match;

import java.net.URL;
import java.sql.Timestamp;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Match;
import com.tournament.repositories.MatchOperations;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class ListMatchController implements Initializable {

	MatchOperations matchOperations = new MatchOperations();
	List<Match> matchList = null;
	TableView<Match> table = new TableView<Match>();
	TableColumn<Match, Integer> idCol = new TableColumn<Match, Integer>("Id");
	TableColumn<Match, String> refreeCol = new TableColumn<Match, String>("Refree");
	TableColumn<Match, String> tournamentCol = new TableColumn<Match, String>("Tournament");
	TableColumn<Match, String> teamHomeCol = new TableColumn<Match, String>("Team Home Name");
	TableColumn<Match, String> teamAwayCol = new TableColumn<Match, String>("Team Away Name");
	TableColumn<Match, Integer> teamHomeScoreCol = new TableColumn<Match, Integer>("Team Home Score");
	TableColumn<Match, Integer> teamAwayScoreCol = new TableColumn<Match, Integer>("Team Away Score");
	TableColumn<Match, Integer> locationCol = new TableColumn<Match, Integer>("Pitch");
	TableColumn<Match, Timestamp> fromTimeCol = new TableColumn<Match, Timestamp>("From Time");
	TableColumn<Match, Timestamp> toTimeCol = new TableColumn<Match, Timestamp>("From Time");

	@FXML
	VBox vbox;
	@FXML
	BorderPane borderPane;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			matchList = matchOperations.list();
			idCol.setCellValueFactory(new PropertyValueFactory<Match, Integer>("id"));
			idCol.setResizable(true);
			refreeCol.setCellValueFactory(new PropertyValueFactory<Match, String>("refreeName"));
			refreeCol.setResizable(true);
			tournamentCol.setCellValueFactory(new PropertyValueFactory<Match, String>("tournamentName"));
			tournamentCol.setResizable(true);
			teamHomeCol.setCellValueFactory(new PropertyValueFactory<Match, String>("teamHomeName"));
			teamHomeCol.setResizable(true);
			teamAwayCol.setCellValueFactory(new PropertyValueFactory<Match, String>("teamAwayName"));
			teamAwayCol.setResizable(true);
			teamHomeScoreCol.setCellValueFactory(new PropertyValueFactory<Match, Integer>("teamHomeScore"));
			teamHomeScoreCol.setResizable(true);
			teamAwayScoreCol.setCellValueFactory(new PropertyValueFactory<Match, Integer>("teamAwayScore"));
			teamAwayScoreCol.setResizable(true);
			locationCol.setCellValueFactory(new PropertyValueFactory<Match, Integer>("pitchLocation"));
			locationCol.setResizable(true);
			fromTimeCol.setCellValueFactory(new PropertyValueFactory<Match, Timestamp>("fromTime"));
			fromTimeCol.setResizable(true);
			toTimeCol.setCellValueFactory(new PropertyValueFactory<Match, Timestamp>("toTime"));
			toTimeCol.setResizable(true);
			table.getColumns().addAll(idCol, tournamentCol, refreeCol, teamHomeCol, teamAwayCol, teamHomeScoreCol,
					teamAwayScoreCol, locationCol, fromTimeCol, toTimeCol);
			table.setItems(FXCollections.observableArrayList(matchList));
			table.setMaxWidth(700);
			table.setMaxHeight(800);
			table.setEditable(true);
			table.setVisible(true);
			vbox.getChildren().add(table);
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			borderPane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
