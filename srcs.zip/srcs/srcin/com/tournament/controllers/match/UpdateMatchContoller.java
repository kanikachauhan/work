package com.tournament.controllers.match;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.dto.Match;
import com.tournament.repositories.MatchOperations;
import com.tournament.utils.Utils;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class UpdateMatchContoller implements Initializable {

	@FXML
	BorderPane borderPane;
	@FXML
	TextField teamHomeScore, teamAwayScore;

	List<Match> matchList = null;
	TableView<Match> table = new TableView<Match>();
	TableColumn<Match, Integer> idCol = new TableColumn<Match, Integer>("Id");
	TableColumn<Match, String> refreeCol = new TableColumn<Match, String>("Refree");
	TableColumn<Match, String> tournamentCol = new TableColumn<Match, String>("Tournament");
	TableColumn<Match, String> teamHomeCol = new TableColumn<Match, String>("Team Home Name");
	TableColumn<Match, String> teamAwayCol = new TableColumn<Match, String>("Team Away Name");
	MatchOperations matchOperations = new MatchOperations();
	@FXML
	private Label errorLabel;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			matchList = matchOperations.list();
			idCol.setCellValueFactory(new PropertyValueFactory<Match, Integer>("id"));
			idCol.setResizable(true);
			refreeCol.setCellValueFactory(new PropertyValueFactory<Match, String>("refreeName"));
			refreeCol.setResizable(true);
			tournamentCol.setCellValueFactory(new PropertyValueFactory<Match, String>("tournamentName"));
			tournamentCol.setResizable(true);
			teamHomeCol.setCellValueFactory(new PropertyValueFactory<Match, String>("teamHomeName"));
			teamHomeCol.setResizable(true);
			teamAwayCol.setCellValueFactory(new PropertyValueFactory<Match, String>("teamAwayName"));
			teamAwayCol.setResizable(true);
			table.getColumns().addAll(idCol, tournamentCol, refreeCol, teamHomeCol, teamAwayCol);
			table.setItems(FXCollections.observableArrayList(matchList));
			table.setMaxWidth(650);
			table.setMaxHeight(800);
			table.setEditable(true);
			table.setVisible(true);
			borderPane.setLeft(table);
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			borderPane.setTop(root);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void updateMatch() {
		int index = table.getSelectionModel().getSelectedIndex();
		if (index == -1) {
			errorLabel.setText("Select a match first for update");
			return;
		} else {
			if (!Utils.validateRegex("[0-9]+", teamAwayScore.getText())) {
				errorLabel.setText("Team Away Score Invalid");
				return;
			}
			if (!Utils.validateRegex("[0-9]+", teamHomeScore.getText())) {
				errorLabel.setText("Team Home Score Invalid");
				return;
			}
			errorLabel.setText("Selected Match Id: " + index);
			Match selectedMatch = matchList.get(index);
			selectedMatch.setTeamAwayScore(Integer.parseInt(teamAwayScore.getText()));
			selectedMatch.setTeamHomeScore(Integer.parseInt(teamHomeScore.getText()));
			boolean status = matchOperations.update(selectedMatch);
			if (status) {
				errorLabel.setText("Value Updated");
			} else {
				errorLabel.setText("Error In Update");
			}
		}
	}
}
