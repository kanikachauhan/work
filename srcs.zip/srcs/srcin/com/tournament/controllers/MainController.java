package com.tournament.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import com.tournament.controllers.player.AddPlayerController;
import com.tournament.utils.Constants;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class MainController implements Initializable{

	@FXML
	BorderPane mainPane;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			FXMLLoader loader = new FXMLLoader(AddPlayerController.class.getResource("/com/tournament/fxml/Menu.fxml"));
			AnchorPane root = loader.load();
			mainPane.setTop(root);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	public void scheduleTournament() {
		BorderPane root;
		try {
			root = FXMLLoader.load(getClass().getClassLoader().getResource("com/tournament/fxml/tournament/ScheduleTournament.fxml"));
			Scene scene = new Scene(root,1200,700);
			Constants.stageGenerator.primaryStage.setScene(scene);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
