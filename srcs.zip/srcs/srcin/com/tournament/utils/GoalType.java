package com.tournament.utils;

public enum GoalType {

	NORMAL(1),OWN_GOAL(2),PENALTY(3);
	private int type;
	
	GoalType(int type){
		this.type = type;
	}
	public int getGoalType() {
		return this.type;
	}
}
