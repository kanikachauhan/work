package com.tournament.utils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Pattern;

public class Utils {

	public static boolean validateRegex(String string, String pattern) {
		return Pattern.matches(string, pattern);
	}

	public static Date addDateTime(int time, Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MINUTE, time);
		return calendar.getTime();
	}
	public static Double roundToTwoPlaces(Double val) {
		return new BigDecimal(val.toString()).setScale(2,RoundingMode.HALF_UP).doubleValue();
	}
}
