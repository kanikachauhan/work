package com.tournament.utils;

public enum Bucket {

	BAD(1,3),AVERAGE(4,6),GOOD(7,10);
	private int min,max;
	Bucket(int min,int max){
		this.min = min;
		this.max = max;
	}
	public int getMin() {
		return this.min;
	}
	public int getMax() {
		return this.max;
	}
}
