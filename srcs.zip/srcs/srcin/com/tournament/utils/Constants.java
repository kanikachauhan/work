package com.tournament.utils;

import com.tournament.configuration.StageGenerator;

public class Constants {
	
	public static final String USER_NAME = "username";
	public static final String HOST_URL = "hosturl";
	public static final String PASS_WORD = "password";
	public static final String DATABASE_NAME = "databasename";
	public static final String DATABASE_DRIVER = "driver";
	public static StageGenerator stageGenerator = null;
}
