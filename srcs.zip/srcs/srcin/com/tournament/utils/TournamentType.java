package com.tournament.utils;

public enum TournamentType {

	KNOCK_OUT(1),ROUND_ROBIN(2),NOT_APPLICABLE(3);
	private int type;
	
	TournamentType(int type){
		this.type = type;
	}
	public int getTournamentType() {
		return this.type;
	}
}
