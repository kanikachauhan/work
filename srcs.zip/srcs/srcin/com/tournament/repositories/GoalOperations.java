package com.tournament.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tournament.configuration.DBConfig;
import com.tournament.dto.Goal;
import com.tournament.dto.Match;
import com.tournament.utils.GoalType;
import com.tournament.repositories.MatchOperations;

public class GoalOperations implements DbOperations<Goal>{

	private static final String INSERT_SQL ="insert into goal (player_id,match_id,type) values (?,?,?)";
	private static final String DELETE_SQL = "delete from goal where id=?";
	private static final String SELECT_SQL = "select * from goal";
	Connection connection = DBConfig.getDatabaseConnection().getConnection();
	MatchOperations matchOperations = new MatchOperations();
	PlayerOperations playerOperations = new PlayerOperations();
	@Override
	public boolean add(Goal goal) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(INSERT_SQL);
			statement.setInt(1, goal.getPlayer());
			statement.setInt(2, goal.getMatch());
			statement.setString(3, goal.getType());
			int rows = statement.executeUpdate();
			if(rows>0) {
				status = true;
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return status;
	}

	@Override
	public List<Goal> list() {
		List<Goal> goalList = new ArrayList<Goal>();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Goal goal = new Goal();
				int id = resultSet.getInt("match_id");
				Match match = matchOperations.getMatchById(id);
				goal.setMatch(id);
				goal.setTeamHome(match.getTeamHomeName());
				goal.setTeamAway(match.getTeamAwayName());
				goal.setId(resultSet.getInt("id"));
				int pid = resultSet.getInt("player_id");
				goal.setPlayer(pid);
				goal.setPlayerName(playerOperations.getPlayerById(pid).getFirstName());
				goal.setType(resultSet.getString("type"));
				goalList.add(goal);
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return goalList;
	}

	@Override
	public boolean delete(int primaryKey) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(DELETE_SQL);
			statement.setInt(1,primaryKey);
			int rows = statement.executeUpdate();
			if(rows>0) {
				status = true;
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return status;
	}

	@Override
	public boolean update(Goal t) {
		// TODO Auto-generated method stub
		return false;
	}

}
