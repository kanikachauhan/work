package com.tournament.repositories;

import com.tournament.dto.Player;
import com.tournament.dto.Team;
import com.tournament.dto.Tournament;

public class TeamPlayerOperations {


	
}
