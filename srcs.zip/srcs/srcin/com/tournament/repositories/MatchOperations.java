package com.tournament.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tournament.configuration.DBConfig;
import com.tournament.dto.Match;

public class MatchOperations implements DbOperations<Match>{

	Connection connection = DBConfig.getDatabaseConnection().getConnection();
	TeamOperations teamOperations = new TeamOperations();
	RefreeOperations refreeOperations = new RefreeOperations();
	PitchOperations pitchOperations = new PitchOperations();
	TournamentOperations tournamentOperations = new TournamentOperations();
	private static final String INSERT_SQL = "insert into tmatch(tournament_id,refree_id,team_home,team_away,from_time,to_time,location_id) values (?,?,?,?,?,?,?)";
	private static final String SELECT_SQL = "select * from tmatch";
	private static final String SELECT_SQL_ID = "select * from tmatch where tournament_id=?";
	private static final String UPDATE_SQL = "update tmatch set team_home_score=?,team_away_score=? where id=?";
	@Override
	public boolean add(Match match) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(INSERT_SQL);
			statement.setInt(1, match.getTournamentId());
			statement.setInt(2, match.getRefreeId());
			statement.setInt(3, match.getTeamHome());
			statement.setInt(4,match.getTeamAway());
			statement.setTimestamp(5, match.getFromTime());
			statement.setTimestamp(6, match.getToTime());
			statement.setInt(7,match.getPitch());
			int rows = statement.executeUpdate();
			if(rows>0){
				status = true;
			}
			}catch(Exception ex) {
				ex.printStackTrace();
			}return status;
		}
		
	
	@Override
	public List<Match> list() {
		List<Match> matchList = new ArrayList<Match>();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Match match = new Match();
				match.setId(resultSet.getInt("id"));
				int pid = resultSet.getInt("location_id");
				match.setPitch(pid);
				match.setPitchLocation(pitchOperations.getPitchById(pid).getLocation());
				int rid = resultSet.getInt("refree_id");
				match.setRefreeId(rid);
				match.setRefreeName(refreeOperations.getRefreeById(rid).getFirstName());
				int taid = resultSet.getInt("team_away");
				match.setTeamAway(taid);
				match.setTeamAwayName(teamOperations.getTeamById(taid).getName());
				int thid =resultSet.getInt("team_home");
				match.setTeamHome(thid);
				match.setTeamHomeName(teamOperations.getTeamById(thid).getName());
				match.setTeamHomeScore(resultSet.getInt("team_home_score"));
				match.setTeamAwayScore(resultSet.getInt("team_away_score"));
				match.setFromTime(resultSet.getTimestamp("from_time"));
				match.setToTime(resultSet.getTimestamp("to_time"));
				int tid = resultSet.getInt("tournament_id");
				match.setTournamentId(tid);
				match.setTournamentName(tournamentOperations.getTournamentById(tid).getName());
				matchList.add(match);
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return matchList;
	}
	
	
	public List<Match> listMatchByTournament(int id) {
		List<Match> matchList = new ArrayList<Match>();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL_ID);
			statement.setInt(1, id);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Match match = new Match();
				match.setId(resultSet.getInt("id"));
				int pid = resultSet.getInt("location_id");
				match.setPitch(pid);
				match.setPitchLocation(pitchOperations.getPitchById(pid).getLocation());
				int rid = resultSet.getInt("refree_id");
				match.setRefreeId(rid);
				match.setRefreeName(refreeOperations.getRefreeById(rid).getFirstName());
				int taid = resultSet.getInt("team_away");
				match.setTeamAway(taid);
				match.setTeamAwayName(teamOperations.getTeamById(taid).getName());
				int thid =resultSet.getInt("team_home");
				match.setTeamHome(thid);
				match.setTeamHomeName(teamOperations.getTeamById(thid).getName());
				match.setTeamHomeScore(resultSet.getInt("team_home_score"));
				match.setTeamAwayScore(resultSet.getInt("team_away_score"));
				match.setFromTime(resultSet.getTimestamp("from_time"));
				match.setToTime(resultSet.getTimestamp("to_time"));
				int tid = resultSet.getInt("tournament_id");
				match.setTournamentId(tid);
				match.setTournamentName(tournamentOperations.getTournamentById(tid).getName());
				matchList.add(match);
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return matchList;
	}
	
	

	public Match getMatchById(int primaryKey) {
		Match match = new Match();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				match.setId(resultSet.getInt("id"));
				int pid = resultSet.getInt("location_id");
				match.setPitch(pid);
				match.setPitchLocation(pitchOperations.getPitchById(pid).getLocation());
				int rid = resultSet.getInt("refree_id");
				match.setRefreeId(rid);
				match.setRefreeName(refreeOperations.getRefreeById(rid).getFirstName());
				int taid = resultSet.getInt("team_away");
				match.setTeamAway(taid);
				match.setTeamAwayName(teamOperations.getTeamById(taid).getName());
				int thid =resultSet.getInt("team_home");
				match.setTeamHome(thid);
				match.setTeamHomeName(teamOperations.getTeamById(thid).getName());
				match.setTeamHomeScore(resultSet.getInt("team_home_score"));
				match.setTeamAwayScore(resultSet.getInt("team_away_score"));
				match.setFromTime(resultSet.getTimestamp("from_time"));
				match.setToTime(resultSet.getTimestamp("to_time"));
				int tid = resultSet.getInt("tournament_id");
				match.setTournamentId(tid);
				match.setTournamentName(tournamentOperations.getTournamentById(tid).getName());
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return match;
	}
	
	@Override
	public boolean delete(int primaryKey) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Match match) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(UPDATE_SQL);
			statement.setInt(1, match.getTeamHomeScore());
			statement.setInt(2, match.getTeamAwayScore());
			statement.setInt(3, match.getId());
			int rows = statement.executeUpdate();
			if(rows>0) {
				status = true;
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return status;
	}

}
