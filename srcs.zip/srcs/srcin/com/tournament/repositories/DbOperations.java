package com.tournament.repositories;

import java.util.List;

public interface DbOperations<T> {

	public boolean add(T t);
	
	public List<T> list();
	
	public boolean delete(int primaryKey);
	
	public boolean update(T t);
}
