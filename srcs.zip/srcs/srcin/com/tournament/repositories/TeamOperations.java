package com.tournament.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.tournament.configuration.DBConfig;
import com.tournament.dto.Player;
import com.tournament.dto.Team;
import com.tournament.dto.Tournament;

public class TeamOperations implements DbOperations<Team>{

	private static final String INSERT_SQL="insert into team(name,tournament_id) values (?,?)";
	private static final String INSERT_PTT_MAPPING="insert into team_player(team_id,player_id,tournament_id) values(?,?,?)";
	private static final String SELECT_SQL = "select * from team";
	private static final String SELECT_TEAM_BY_TOURNAMENT = "select * from team where tournament_id=?";
	private static final String SELECT_SQL_ID = "select * from team where id=?";
	private static final String DELETE_SQL = "delete from team where id=?";
	private static final String UPDATE_SQL = "update team set won=?,lost=?,draw=? where id=?";
	Connection connection = DBConfig.getDatabaseConnection().getConnection();
	@Override
	public boolean add(Team t) {
		boolean status = false;
		try {
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return status;
	}
	public Team getTeamById(int id) {
		Team team = new Team();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL_ID);
			statement.setInt(1, id);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				team.setId(resultSet.getInt("id"));
				team.setName(resultSet.getString("name"));
				team.setDrawn(resultSet.getInt("draw"));
				team.setLost(resultSet.getInt("lost"));
				team.setWon(resultSet.getInt("won"));
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return team;
	}
	public boolean createPlayerTeamTournamentMapping(Team team,Player player,Tournament tournament) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(INSERT_PTT_MAPPING);
			statement.setInt(1,team.getId());
			statement.setInt(2, player.getId());
			statement.setInt(3, tournament.getId());
			int result = statement.executeUpdate();
			if(result>0){
				status = true;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return status;
	}
	public int createTeam(Team team,int tournament_id) {
		int key = -1;
		try {
			PreparedStatement statement = connection.prepareStatement(INSERT_SQL,Statement.RETURN_GENERATED_KEYS);
			statement.setString(1,team.getName());
			statement.setInt(2, tournament_id);
			statement.executeUpdate();
			ResultSet resultSet = statement.getGeneratedKeys();
			while(resultSet.next()) {
				key = resultSet.getInt(1);
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return  key;
	}
	public List<Team> teamListByTournament(int key){
		List<Team> teamList = new ArrayList<Team>();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_TEAM_BY_TOURNAMENT);
			statement.setInt(1, key);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Team team = new Team();
				team.setDrawn(resultSet.getInt("draw"));
				team.setLost(resultSet.getInt("lost"));
				team.setName(resultSet.getString("name"));
				team.setWon(resultSet.getInt("won"));
				team.setId(resultSet.getInt("id"));
				teamList.add(team);
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return teamList;
	}
	
	@Override
	public List<Team> list() {
		List<Team> teamList = new ArrayList<Team>();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Team team = new Team();
				team.setDrawn(resultSet.getInt("draw"));
				team.setLost(resultSet.getInt("lost"));
				team.setName(resultSet.getString("name"));
				team.setWon(resultSet.getInt("won"));
				team.setId(resultSet.getInt("id"));
				teamList.add(team);
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return teamList;
	}
	
	@Override
	public boolean delete(int primaryKey) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(DELETE_SQL);
			statement.setInt(1, primaryKey);
			int rows = statement.executeUpdate();
			if(rows>0) {
				status = true;
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return status;
	}

	@Override
	public boolean update(Team team) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(UPDATE_SQL);
			statement.setInt(1,team.getWon());
			statement.setInt(2, team.getLost());
			statement.setInt(3, team.getDrawn());
			statement.setInt(4, team.getId());
			int rows = statement.executeUpdate();
			if(rows>0) {
				status = true;
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return status;
	}

}
