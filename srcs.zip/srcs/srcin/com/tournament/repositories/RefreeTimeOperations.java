package com.tournament.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tournament.configuration.DBConfig;
import com.tournament.dto.RefreeTime;

public class RefreeTimeOperations implements DbOperations<RefreeTime>{

	private static final String SELECT_SQL = "select * from refree_time where refree_id=?";
	private static final String INSERT_SQL = "insert into refree_time (refree_id,fromTime,toTime) values (?,?,?)";
	Connection connection = DBConfig.getDatabaseConnection().getConnection();
	@Override
	public boolean add(RefreeTime refreeTime) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(INSERT_SQL);		
			statement.setInt(1, refreeTime.getRefreeId());
			statement.setTimestamp(2, refreeTime.getFromTime());
			statement.setTimestamp(3, refreeTime.getToTime());
			int rows = statement.executeUpdate();
			if(rows>0) {
				status = true;
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return status;
	}

	@Override
	public List<RefreeTime> list() {
		List<RefreeTime> list = new ArrayList<RefreeTime>();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				RefreeTime refreeTime = new RefreeTime();
				refreeTime.setId(resultSet.getInt("id"));
				refreeTime.setRefreeId(resultSet.getInt("refree_id"));
				refreeTime.setFromTime(resultSet.getTimestamp("fromTime"));
				refreeTime.setToTime(resultSet.getTimestamp("toTime"));
				list.add(refreeTime);
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return list;
	}

	public List<RefreeTime> getList(int id){
		List<RefreeTime> list = new ArrayList<RefreeTime>();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL);
			statement.setInt(1, id);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				RefreeTime refreeTime = new RefreeTime();
				refreeTime.setId(resultSet.getInt("id"));
				refreeTime.setRefreeId(resultSet.getInt("refree_id"));
				refreeTime.setFromTime(resultSet.getTimestamp("fromTime"));
				refreeTime.setToTime(resultSet.getTimestamp("toTime"));
				list.add(refreeTime);
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return list;
	}

	@Override
	public boolean delete(int primaryKey) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(RefreeTime t) {
		// TODO Auto-generated method stub
		return false;
	}

	
}
