package com.tournament.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.tournament.configuration.DBConfig;
import com.tournament.dto.Tournament;

public class TournamentOperations implements DbOperations<Tournament>{

	private static final String INSERT_SQL="insert into tournament(name,from_time,to_time) values (?,?,?)";
	private static final String SELECT_SQL = "select * from tournament";
	private static final String SELECT_SQL_ID = "select * from tournament where id=?";
	private static final String UPDATE_TOURNAMENT_TYPE = "update tournament set type=? where id=?";
	Connection connection = DBConfig.getDatabaseConnection().getConnection();
	
	public boolean updateTournamentType(int type,int id) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(UPDATE_TOURNAMENT_TYPE);
			statement.setInt(1, type);
			statement.setInt(2, id);
			int rows = statement.executeUpdate();
			if(rows>0) {
				status = true;
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return status;
	}
	
	public Tournament getTournamentById(int key) {
		Tournament tournament = new Tournament();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL_ID);
			statement.setInt(1, key);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				tournament.setId(resultSet.getInt("id"));
				tournament.setName(resultSet.getString("name"));
				tournament.setFromTime(resultSet.getTimestamp("from_time"));
				tournament.setToTime(resultSet.getTimestamp("to_time"));
				tournament.setType(resultSet.getInt("type"));
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}return tournament;
	}
	
	@Override
	public boolean add(Tournament tournament) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(INSERT_SQL,Statement.RETURN_GENERATED_KEYS);
			statement.setString(1,tournament.getName());
			statement.setTimestamp(2, tournament.getFromTime());
			statement.setTimestamp(3, tournament.getToTime());
			int insertRows = statement.executeUpdate();
			if(insertRows>0) {
				status = true;
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return status;
	}
	public int createTournament(Tournament tournament) {
		int key = -1;
		try {
			PreparedStatement statement = connection.prepareStatement(INSERT_SQL,Statement.RETURN_GENERATED_KEYS);
			statement.setString(1,tournament.getName());
			statement.setTimestamp(2, tournament.getFromTime());
			statement.setTimestamp(3, tournament.getToTime());
			statement.executeUpdate();
			ResultSet resultSet = statement.getGeneratedKeys();
			while(resultSet.next()) {
				key = resultSet.getInt(1);
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}		
		return key;
	}

	@Override
	public List<Tournament> list() {
		List<Tournament> tournamentList = new ArrayList<Tournament>();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Tournament tournament = new Tournament();
				tournament.setId(resultSet.getInt("id"));
				tournament.setName(resultSet.getString("name"));
				tournament.setFromTime(resultSet.getTimestamp("from_time"));
				tournament.setToTime(resultSet.getTimestamp("to_time"));
				
					tournament.setType(resultSet.getInt("type"));
				
				tournamentList.add(tournament);
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return tournamentList;
	}

	@Override
	public boolean delete(int primaryKey) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Tournament t) {
		// TODO Auto-generated method stub
		return false;
	}

	

}
