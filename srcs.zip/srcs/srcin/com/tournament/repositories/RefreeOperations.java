package com.tournament.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tournament.configuration.DBConfig;
import com.tournament.dto.Refree;
import com.tournament.dto.RefreeTime;

public class RefreeOperations implements DbOperations<Refree>{

	Connection connection = DBConfig.getDatabaseConnection().getConnection();
	private static final String INSERT_SQL = "insert into "
			+ "refree(firstName,lastName,age,gender,address,contactNumber,email) values (?,?,?,?,?,?,?)";
	private static final String SELECT_SQL = "select * from refree";
	private static final String DELETE_SQL = "delete from refree where id=?";
	private static final String UPDATE_SQL = "update refree set firstName=?,lastName=?,age=?,"
			+ "gender=?,address=?,contactNumber=?,email=? where id = ?";
	private static final String SELECT_SQL_ID="select * from refree where id=?";
	@Override
	public boolean add(Refree refree) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(INSERT_SQL);
			statement.setString(1, refree.getFirstName());
			statement.setString(2, refree.getLastName());
			statement.setInt(3, refree.getAge());
			statement.setString(4, Character.toString(refree.getGender()));
			statement.setString(5, refree.getAddress());
			statement.setString(6, refree.getContactNumber());
			statement.setString(7, refree.getEmail());
			int rows = statement.executeUpdate();
			if(rows>0) {
				status = true;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return status;
	}
	
	

	@Override
	public List<Refree> list() {
		List<Refree> refreeList = new  ArrayList<Refree>();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Refree refree = new Refree();
				refree.setId(resultSet.getInt("id"));
				refree.setAddress(resultSet.getString("address"));
				refree.setAge(resultSet.getInt("age"));
				refree.setContactNumber(resultSet.getString("contactNumber"));
				refree.setEmail(resultSet.getString("email"));
				refree.setFirstName(resultSet.getString("firstName"));
				refree.setLastName(resultSet.getString("lastName"));
				refree.setGender(resultSet.getString("gender").charAt(0));
				refreeList.add(refree);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return refreeList;
	}

	
	public Refree getRefreeById(int id) {
		Refree refree = new Refree();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL_ID);
			statement.setInt(1, id);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				refree.setId(resultSet.getInt("id"));
				refree.setAddress(resultSet.getString("address"));
				refree.setAge(resultSet.getInt("age"));
				refree.setContactNumber(resultSet.getString("contactNumber"));
				refree.setEmail(resultSet.getString("email"));
				refree.setFirstName(resultSet.getString("firstName"));
				refree.setLastName(resultSet.getString("lastName"));
				refree.setGender(resultSet.getString("gender").charAt(0));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return refree;
	}

	
	@Override
	public boolean delete(int primaryKey) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(DELETE_SQL);
			statement.setInt(1, primaryKey);
			int rows = statement.executeUpdate();
			if(rows>0) {
				status = true;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public boolean update(Refree refree) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(UPDATE_SQL);
			statement.setString(1, refree.getFirstName());
			statement.setString(2, refree.getLastName());
			statement.setInt(3, refree.getAge());
			statement.setString(4, Character.toString(refree.getGender()));
			statement.setString(5, refree.getAddress());
			statement.setString(6, refree.getContactNumber());
			statement.setString(7, refree.getEmail());
			statement.setInt(8, refree.getId());
			int rows = statement.executeUpdate();
			if(rows>0) {
				status = true;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return status;
	}
}
