package com.tournament.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tournament.configuration.DBConfig;
import com.tournament.dto.Pitch;

public class PitchOperations implements DbOperations<Pitch>{

	Connection connection = DBConfig.getDatabaseConnection().getConnection();
	private static final String INSERT_SQL = "insert into "
			+ "pitch(location) values (?)";
	private static final String SELECT_SQL = "select * from pitch";
	private static final String DELETE_SQL = "delete from pitch where id=?";
	private static final String UPDATE_SQL = "update pitch set location=? where id = ?";
	private static final String SELECT_SQL_ID = "select * from pitch where id=?";
	
	@Override
	public boolean add(Pitch pitch) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(INSERT_SQL);
			statement.setString(1, pitch.getLocation());
			int rows = statement.executeUpdate();
			if(rows>0) {
				status = true;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public List<Pitch> list() {
		List<Pitch> pitchList = new  ArrayList<Pitch>();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Pitch pitch = new Pitch();
				pitch.setId(resultSet.getInt("id"));
				pitch.setLocation(resultSet.getString("location"));
				pitchList.add(pitch);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return pitchList;
	}
	
	public Pitch getPitchById(int id) {
		Pitch pitch =new  Pitch();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL_ID);
			statement.setInt(1, id);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				pitch.setId(resultSet.getInt("id"));
				pitch.setLocation(resultSet.getString("location"));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return pitch;
	}

	@Override
	public boolean delete(int primaryKey) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(DELETE_SQL);
			statement.setInt(1, primaryKey);
			int rows = statement.executeUpdate();
			if(rows>0) {
				status = true;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public boolean update(Pitch pitch) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(UPDATE_SQL);
			statement.setString(1, pitch.getLocation());
			statement.setInt(2, pitch.getId());
			int rows = statement.executeUpdate();
			if(rows>0) {
				status = true;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return status;
	}

}
