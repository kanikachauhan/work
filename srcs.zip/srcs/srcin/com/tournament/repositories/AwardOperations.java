package com.tournament.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tournament.configuration.DBConfig;
import com.tournament.dto.Award;
import com.tournament.dto.Player;
import com.tournament.dto.Tournament;

public class AwardOperations implements DbOperations<Award>{

	private static final String INSERT_SQL = "insert into award(tournament_id,player_id,name) values (?,?,?)";
	private static final String SELECT_SQL = "select * from award";
	private static final String DELETE_SQL = "delete from award where id=?";
	Connection connection = DBConfig.getDatabaseConnection().getConnection();
	PlayerOperations playerOperations = new PlayerOperations();
	TournamentOperations tournamentOperations = new TournamentOperations();
	public boolean createAward(Tournament tournament,Player player,String name) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(INSERT_SQL);
			statement.setInt(1, tournament.getId());
			statement.setInt(2, player.getId());
			statement.setString(3, name);
			statement.executeUpdate();
			status = true;
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return status;
	}
	
	@Override
	public boolean add(Award t) {
		
		return false;
	}

	@Override
	public List<Award> list() {
		List<Award> awardList = new ArrayList<Award>();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Award award = new Award();
				award.setId(resultSet.getInt("id"));
				award.setName(resultSet.getString("name"));
				int pid = resultSet.getInt("player_id");
				award.setReceiver(pid);
				int tid = resultSet.getInt("tournament_id");
				award.setTournament(tid);
				award.setPlayerName(playerOperations.getPlayerById(pid).getFirstName());
				award.setTournamentName(tournamentOperations.getTournamentById(tid).getName());
				awardList.add(award);
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return awardList;
	}

	@Override
	public boolean delete(int primaryKey) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(DELETE_SQL);
			statement.setInt(1, primaryKey);
			int rows = statement.executeUpdate();
			if(rows>0) {
				status = true;
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return status;
	}

	@Override
	public boolean update(Award t) {
		// TODO Auto-generated method stub
		return false;
	}

	
}
