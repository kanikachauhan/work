package com.tournament.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tournament.configuration.DBConfig;
import com.tournament.dto.Player;

public class PlayerOperations implements DbOperations<Player>{

	Connection connection = DBConfig.getDatabaseConnection().getConnection();
	private static final String INSERT_SQL = "insert into "
			+ "player(firstName,lastName,gender,address,contactNumber,email,position,defending,"
			+ "attacking,shooting,speed,physical) values (?,?,?,?,?,?,?,?,?,?,?,?)";
	private static final String SELECT_SQL = "select * from player";
	private static final String SELECT_SQL_ID = "select * from player where id =?";
	private static final String DELETE_SQL = "delete from player where id=?";
	private static final String UPDATE_SQL = "update player set firstName=?,lastName=?,gender=?,address=?,contactNumber=?,email=?,position=?"
			+ ",defending=?,attacking=?,shooting=?,speed=?,physical=? where id = ?";
	public Player getPlayerById(int key) {
		Player player = new Player();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL_ID);
			statement.setInt(1, key);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				player.setId(resultSet.getInt("id"));
				player.setFirstName(resultSet.getString("firstName"));
				player.setLastName(resultSet.getString("lastName"));
				player.setGender(resultSet.getString("gender").charAt(0));
				player.setEmail(resultSet.getString("email"));
				player.setPosition(resultSet.getString("position"));
				player.setDefending(resultSet.getDouble("defending"));
				player.setAttacking(resultSet.getDouble("attacking"));
				player.setSpeed(resultSet.getDouble("speed"));
				player.setPhysical(resultSet.getDouble("physical"));
				player.setShooting(resultSet.getDouble("shooting"));
				player.setAddress(resultSet.getString("address"));
				player.setContactNumber(resultSet.getString("contactNumber"));
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}return player;
	}
	@Override
	public boolean add(Player player) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(INSERT_SQL);
			statement.setString(1,player.getFirstName());
			statement.setString(2, player.getLastName());
			statement.setString(3, Character.toString(player.getGender()));
			statement.setString(4, player.getAddress());
			statement.setString(5, player.getContactNumber());
			statement.setString(6, player.getEmail());
			statement.setString(7, player.getPosition());
			statement.setDouble(8, player.getDefending());
			statement.setDouble(9, player.getAttacking());
			statement.setDouble(10, player.getShooting());
			statement.setDouble(11, player.getSpeed());
			statement.setDouble(12, player.getPhysical());
			int insertRows = statement.executeUpdate();
			if(insertRows>0) {
				status = true;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public List<Player> list() { 
		List<Player> playerList = new ArrayList<Player>();
		try{
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Player player = new  Player();
				player.setId(resultSet.getInt("id"));
				player.setFirstName(resultSet.getString("firstName"));
				player.setLastName(resultSet.getString("lastName"));
				player.setGender(resultSet.getString("gender").charAt(0));
				player.setEmail(resultSet.getString("email"));
				player.setPosition(resultSet.getString("position"));
				player.setDefending(resultSet.getDouble("defending"));
				player.setAttacking(resultSet.getDouble("attacking"));
				player.setSpeed(resultSet.getDouble("speed"));
				player.setPhysical(resultSet.getDouble("physical"));
				player.setShooting(resultSet.getDouble("shooting"));
				player.setAddress(resultSet.getString("address"));
				player.setContactNumber(resultSet.getString("contactNumber"));
				playerList.add(player);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return playerList;
	}
	
	@Override
	public boolean delete(int primaryKey) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(DELETE_SQL);
			statement.setInt(1, primaryKey);
			int rows = statement.executeUpdate();
			if(rows>0) {
				status = true;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public boolean update(Player player) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(UPDATE_SQL);
			statement.setString(1,player.getFirstName());
			statement.setString(2, player.getLastName());
			statement.setString(3, Character.toString(player.getGender()));
			statement.setString(4, player.getAddress());
			statement.setString(5, player.getContactNumber());
			statement.setString(6, player.getEmail());
			statement.setString(7, player.getPosition());
			statement.setDouble(8, player.getDefending());
			statement.setDouble(9, player.getAttacking());
			statement.setDouble(10, player.getShooting());
			statement.setDouble(11, player.getSpeed());
			statement.setDouble(12, player.getPhysical());
			statement.setInt(13, player.getId());
			int rows = statement.executeUpdate();
			if(rows>0) {
				status = true;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return status;
	}

}
