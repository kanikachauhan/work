package com.tournament.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.tournament.configuration.DBConfig;
import com.tournament.dto.PitchTime;

public class PitchTimeOperations implements DbOperations<PitchTime>{

	private static final String SELECT_SQL = "select * from pitch_time where pitch_id=?";
	private static final String INSERT_SQL = "insert into pitch_time(pitch_id,fromTime,toTime) values (?,?,?)";
	Connection connection = DBConfig.getDatabaseConnection().getConnection();
	@Override
	public boolean add(PitchTime pitchTime) {
		boolean status = false;
		try {
			PreparedStatement statement = connection.prepareStatement(INSERT_SQL);
			statement.setInt(1, pitchTime.getId());
			statement.setTimestamp(2, pitchTime.getFromTime());
			statement.setTimestamp(3, pitchTime.getToTime());
			int rows = statement.executeUpdate();
			if(rows>0) {
				status = true;
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		return status;
	}

	@Override
	public List<PitchTime> list() {
		// TODO Auto-generated method stub
		return null;
	}

	public List<PitchTime> getList(int id){
		List<PitchTime> pitchTimeList = new ArrayList<PitchTime>();
		try {
			PreparedStatement statement = connection.prepareStatement(SELECT_SQL);
			statement.setInt(1, id);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				PitchTime pitchTime = new PitchTime();
				pitchTime.setId(resultSet.getInt("id"));
				pitchTime.setPitch_id(resultSet.getInt("pitch_id"));
				pitchTime.setFromTime(resultSet.getTimestamp("fromTime"));
				pitchTime.setToTime(resultSet.getTimestamp("toTime"));
				pitchTimeList.add(pitchTime);
			}
		}catch(Exception ex) {
			ex.printStackTrace();
		}return pitchTimeList;
	}
	
	@Override
	public boolean delete(int primaryKey) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(PitchTime t) {
		// TODO Auto-generated method stub
		return false;
	}
	
	

}
