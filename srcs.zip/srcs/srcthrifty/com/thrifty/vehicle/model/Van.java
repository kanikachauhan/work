package com.thrifty.vehicle.model;

public class Van extends Vehicle{

}
