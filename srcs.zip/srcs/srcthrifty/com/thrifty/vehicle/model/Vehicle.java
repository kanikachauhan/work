package com.thrifty.vehicle.model;

import java.util.ArrayList;
import java.util.List;

public class Vehicle {

	private String vehicleId;
	private int year;
	private String make;
	private String model;
	private int numberOfSeats;
	private String vehicleType;
	private String vehicleStatus;

	public String getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(String vehicleId) {
		this.vehicleId = vehicleId;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getNumberOfSeats() {
		return numberOfSeats;
	}

	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public String getVehicleStatus() {
		return vehicleStatus;
	}

	public void setVehicleStatus(String vehicleStatus) {
		this.vehicleStatus = vehicleStatus;
	}

	public double lateRentalRate(int days) {
		return 0.0;
	}

	public boolean validateSeats(String numberOfSeats) {
		return false;
	}

	public boolean validateId(String vehicleId) {
		return false;
	}

	public boolean performMaintenance() {
		return false;
	}

	public int rentalRate(int diffDays) {
		return -1;
	}
}
