package com.thrifty.vehicle.model;

public class RentalRecord {

}
