package com.thrifty.vehicle.controller;

public class MainController {

}
