package com.thrifty.vehicle.controller;

public class MenuController {

}
