package com.thriftyrent.vehicle;

import java.util.ArrayList;
import java.util.List;

import com.thriftyrent.vehicle.rent.RentalRecord;
import com.thriftyrent.vehicle.util.DateTime;
import com.thriftyrent.vehicle.util.ValidationUtil;

public class Vehicle {
	
	private String vehicleId;
	private int year;
	private String make;
	private String model;
	private int numberOfSeats;
	private String vehicleType;
	private String vehicleStatus;
	private DateTime lastMaintenanceDate;
	
	public DateTime getLastMaintenanceDate() {
		return lastMaintenanceDate;
	}

	public void setLastMaintenanceDate(DateTime lastMaintenanceDate) {
		this.lastMaintenanceDate = lastMaintenanceDate;
	}

	List<RentalRecord> rentalRecordList;
	
	public String getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(String vehicleId) {
		this.vehicleId = vehicleId;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getNumberOfSeats() {
		return numberOfSeats;
	}

	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public String getVehicleStatus() {
		return vehicleStatus;
	}

	public void setVehicleStatus(String vehicleStatus) {
		this.vehicleStatus = vehicleStatus;
	}
	
	public List<RentalRecord> getRentalRecordList() {
		return rentalRecordList;
	}

	public void setRentalRecordList(List<RentalRecord> rentalRecordList) {
		this.rentalRecordList = rentalRecordList;
	}

	public double lateRentalRate(int days) {
		return 0.0;
	}
	
	public boolean validateSeats(String numberOfSeats) {
		return false;
	}
	
	public boolean validateId(String vehicleId) {
		return false;
	}
	
	public boolean rent(String customerId, DateTime rentDate, int
			numOfRentDay) {
		return false;
	}
	
	public boolean returnVehicle(DateTime returnDate) {
		return false;
	}
	
	public boolean performMaintenance() {
		return false;
	}
	
	public boolean completeMaintenance(DateTime completionDate) {
		return false;
	}
	
	public String toString() {
		String status = null;
		if(this.vehicleStatus.equals("umaintenance")) {
			status = "Under Maintenance";
		}else {
			status = "Available";
		}
		if(this.vehicleType.equalsIgnoreCase("car")) {
			return new StringBuilder().append(vehicleId).append(":").append(year).append(":").append(make).append(":")
				.append(model).append(":").append(numberOfSeats).append(":").append(status).toString();
		}else {
			return new StringBuilder().append(vehicleId).append(":").append(year).append(":").append(make).append(":")
			.append(model).append(":").append(numberOfSeats).append(":").append(status).append(lastMaintenanceDate.getEightDigitDate()).toString();
		}
	}
	
	public String getDetails() {
		String stat = null;
		if(this.vehicleStatus.equals("umaintenance")) {
			stat = "Under Maintenance";
		}else {
			stat = "Available";
		}
		StringBuilder vehicleDetailsBuilder = new StringBuilder();
		String vehicleId = String.format("Vehicle ID:%34s\n", this.vehicleId);
		String year = String.format("Year:%40s\n", this.year);
		String make = String.format("Make:%40s\n",this.make);
		String model = String.format("Model:%39s\n",this.model);
		String numberOfSeats = String.format("Number of seats:%29s\n",this.numberOfSeats);
		String status = String.format("Status:%38s\n",stat);
		vehicleDetailsBuilder.append(vehicleId).append(year).append(make).append(model).append(numberOfSeats).append(status);
		if(vehicleId.startsWith("V")) {
			String lastDate = String.format("Last Maintenance Date:%23s\n", this.lastMaintenanceDate);
			vehicleDetailsBuilder.append(lastDate);
		}else {
			String lastDate = String.format("Last Maintenance Date:Not Found\n");
			vehicleDetailsBuilder.append(lastDate);
		}
		if(this.rentalRecordList==null) {
			String str =String.format("RENTAL RECORD:%31s\n","empty");
			vehicleDetailsBuilder.append(str);
		}else {
			for(RentalRecord recrd:rentalRecordList) {
				vehicleDetailsBuilder.append("---------------------------------------------\n");
				vehicleDetailsBuilder.append(recrd.getDetails()+"\n");
			}
		}
		return vehicleDetailsBuilder.toString();
	}
	
	public int rentalRate(int diffDays) {
		return -1;
	}
}
