package com.thriftyrent.vehicle.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;

public class ValidationUtil {

	private static final String regex = "\\d+";
	
	private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

	/**
	 * validate numeric field
	 * @param input
	 * @return
	 */
	public static boolean validateNumericField(String input) {
		return Pattern.matches(regex, input);
	}
	/**
	 * validate year input
	 * @param input
	 * @return
	 */
	public static boolean validateYear(String input) {
		return Pattern.matches(regex, input) && input.length()==4;
	}
	/**
	 * validate date input
	 * @param input
	 * @return
	 */
	public static LocalDate returnValidDate(String input) {
		LocalDate localDate = null;
		try {
			localDate = LocalDate.parse(input,FORMATTER);
		}catch(Exception ex) {
			ex.printStackTrace();
		}return localDate;
	}
	
}
