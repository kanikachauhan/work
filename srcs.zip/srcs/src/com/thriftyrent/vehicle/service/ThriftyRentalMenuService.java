package com.thriftyrent.vehicle.service;

import java.time.LocalDate;
import java.util.Scanner;

import com.thriftyrent.vehicle.Vehicle;
import com.thriftyrent.vehicle.rent.RentalRecord;
import com.thriftyrent.vehicle.type.Car;
import com.thriftyrent.vehicle.type.Van;
import com.thriftyrent.vehicle.util.DateTime;
import com.thriftyrent.vehicle.util.ValidationUtil;

public class ThriftyRentalMenuService {

	private ThriftyRentalService thriftyRentalService = new ThriftyRentalService();
	private static Scanner scanner = new Scanner(System.in);
	
	/**
	 * main menu creation
	 */
	public void createMenu() {
		System.out.format("     **** ThriftyRent SYSTEM MENU ****\n");
		System.out.format("Add vehicle:%33s", "1\n");
		System.out.format("Rent vehicle:%32s", "2\n");
		System.out.format("Return vehicle:%30s", "3\n");
		System.out.format("Vehicle Maintenance:%25s", "4\n");
		System.out.format("Complete Maintenance:%24s", "5\n");
		System.out.format("Display All Vehicles:%24s", "6\n");
		System.out.format("Exit Program:%32s", "7\n");
		System.out.format("Enter Choice:");
		String input = scanner.nextLine();
		processChoice(input);
	}

	
	/**
	 * choices
	 */
	public void processChoice(String input) {
		switch (input) {
		case ("1"):
			addVehicleMenu();
			break;
		case ("2"):
			rentVehicle();
			break;
		case ("3"):
			returnVehicle();
			break;
		case ("4"):
			maintainVehicle();
			break;
		case ("5"):
			completeMaintenance();
			break;
		case ("6"):
			displayVehicles();
			break;
		case ("7"):
			System.exit(1);
		default:
			System.out.format("%30s", "Wrong Choice\n");
			createMenu();
			break;
		}
	}
	
	/**
	 * menu for vehicle addition
	 */
	private void addVehicleMenu() {
		System.out.format("Vehicle type:");
		String vehicleType = scanner.nextLine();
		if(!thriftyRentalService.validateVehicle(vehicleType)) {
			System.out.format("Invalid Vehicle Type. Ishould be car or van.\n");
			createMenu();
		}
		Vehicle vehicle = thriftyRentalService.returnValidVehicleType(vehicleType);
		System.out.format("Vehicle id:");
		String vehicleId = scanner.nextLine();
		if(!vehicle.validateId(vehicleId)) {
			System.out.format("Invalid Vehicle Id, for car it should start with C_ for van it should start with V_.\n");
			createMenu();
		}
		System.out.format("Manufacturing year:");
		String year = scanner.nextLine();
		if(!ValidationUtil.validateYear(year)) {
			System.out.format("Invalid Year of manufacture.\n");
			createMenu();
		}
		System.out.format("Vehicle make:");
		String make = scanner.nextLine();
		System.out.format("Vehicle model:");
		String model = scanner.nextLine();
		String numberOfSeats = null;
		if(vehicleId.startsWith("V")) {
			numberOfSeats = "15";
		}else {
			System.out.format("Number of seats:");
			numberOfSeats =scanner.nextLine();
			if(!vehicle.validateSeats(numberOfSeats)) {
				System.out.format("Invalid Seats, for car it should be between 4 or 7 for van it should be 15.\n");
				createMenu();
			}
		}
		vehicle.setVehicleId(vehicleId);
		vehicle.setYear(Integer.parseInt(year));
		vehicle.setMake(make);
		vehicle.setModel(model);
		vehicle.setNumberOfSeats(Integer.parseInt(numberOfSeats));
		vehicle.setVehicleStatus("Available");
		if(vehicleId.startsWith("V")) {
			System.out.format("Last Maintenance Date(dd/MM/yyyy):");
			String lastMaintenanceDate = scanner.nextLine();
			LocalDate localDate = ValidationUtil.returnValidDate(lastMaintenanceDate);
			if(localDate==null) {
				System.out.format("Invalid last maintenance date.\n");
				createMenu();
			}
			vehicle.setLastMaintenanceDate(new DateTime(localDate.getDayOfMonth(), localDate.getMonthValue(), localDate.getYear()));
		}
		if(thriftyRentalService.checkIfIdExists(vehicle.getVehicleId())) {
			System.out.format("Vehicle with this id exists.\n");
			createMenu();
		}
		if(thriftyRentalService.addVehicle(vehicle)) {
			System.out.format("Vehicle added.\n");
		}else {
			System.out.format("Vehicle not added.\n");
		}
		createMenu();
	}
	
	/**
	 * menu for vehicle rental
	 */
	private void rentVehicle() {
		System.out.format("Vehicle Id:");
		String vehicleId = scanner.nextLine();
		if(!thriftyRentalService.checkIfIdExists(vehicleId)) {
			System.out.format("Vehicle with id %s do not exists.\n",vehicleId);
			createMenu();
		}
		System.out.format("Customer Id:");
		String customerId = scanner.nextLine();
		System.out.format("Rent date(dd/MM/yyyy):");
		String rentDate = scanner.nextLine();
		LocalDate rentalDate = ValidationUtil.returnValidDate(rentDate);
		if(rentalDate==null) {
			System.out.format("Invalid rent date.\n");
			createMenu();
		}
		System.out.format("How many days?:");
		String numberOfDays = scanner.nextLine();
		if(!ValidationUtil.validateNumericField(numberOfDays)) {
			System.out.format("Invalid number of days.\n");
			createMenu();
		}
		String status = thriftyRentalService.rentVehicle(vehicleId, customerId, rentalDate, numberOfDays);
		if(status.equals("success")) {
			System.out.format("Vehicle %s is now rented by customer %s \n", vehicleId,customerId);
		}else {
			System.out.format("Unable to rent vehicle %s to customer %s, reason %s  \n",vehicleId,customerId,status);
		}
		createMenu();
	}
	/**
	 * menu for vehicle return
	 */
	private void returnVehicle() {
		System.out.format("Vehicle Id:");
		String vehicleId = scanner.nextLine();
		if(!thriftyRentalService.checkIfIdExists(vehicleId)) {
			System.out.format("Vehicle with id %s do not exists.\n",vehicleId);
			createMenu();
		}
		System.out.format("Return date( dd/MM/yyyy):");
		String returnDate = scanner.nextLine();
		LocalDate localeDate = ValidationUtil.returnValidDate(returnDate);
		if(localeDate==null) {
			System.out.format("Invalid return date.\n");
			createMenu();
		}
		Vehicle result = thriftyRentalService.returnVehicle(vehicleId, localeDate);
		if(result.getVehicleStatus().equals("Available")) {
			System.out.format("Vehicle returned with status %s  \n",result.getVehicleStatus());
			RentalRecord latestRentalRecord = result.getRentalRecordList().get(0);
			System.out.format("Rental Record Status %s \n",latestRentalRecord.getDetails());
		}else {
			System.out.format("Vehicle cannot be returned status %s  \n",result.getVehicleStatus());
		}
		createMenu();
	}
	/**
	 * menu for maintain vehicle
	 */
	private void maintainVehicle() {
		System.out.format("Vehicle Id:");
		String vehicleId = scanner.nextLine();
		if(!thriftyRentalService.checkIfIdExists(vehicleId)) {
			System.out.format("Vehicle with id %s do not exists.\n",vehicleId);
			createMenu();
		}
		Vehicle status = thriftyRentalService.maintainVehicle(vehicleId);
		if(status.getVehicleStatus().equals("umaintenance")) {
			System.out.format("Vehicle %s under maintenance  \n",vehicleId);
		}else {
			System.out.format("Vehicle %s cannot be sent to maintenance  \n",vehicleId);
		}
		createMenu();
	}
	/**
	 * menu for complete maintenance
	 */
	private void completeMaintenance() {
		System.out.format("Vehicle Id:");
		String vehicleId = scanner.nextLine();
		if(!thriftyRentalService.checkIfIdExists(vehicleId)) {
			System.out.format("Vehicle with this id do not exists.\n");
			createMenu();
		}
		String status =  null;
		if(vehicleId.startsWith("V")) {
			System.out.format("Maintenance Completion Date( dd/MM/yyyy):");
			String returnDate = scanner.nextLine();
			LocalDate localeDate = ValidationUtil.returnValidDate(returnDate);
			if(localeDate==null) {
				System.out.format("Invalid completion date.\n");
				createMenu();
			}
			status = thriftyRentalService.completeMaintenance(vehicleId,localeDate);
		}else {
			status = thriftyRentalService.completeMaintenance(vehicleId,null);
		}
		if(status.equals("success")) {
			System.out.format("Vehicle %s maintenance completed  \n",vehicleId);
		}else {
			System.out.format("Vehicle %s maintenance cannot be completed  \n",vehicleId);
		}
		createMenu();
	}
	/**
	 * menu for vehicle display
	 */
	
	private void displayVehicles() {
		System.out.print(thriftyRentalService.displayAllVehicles());
		createMenu();
	}
}
