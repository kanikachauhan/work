package com.thriftyrent.vehicle.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.thriftyrent.vehicle.Vehicle;
import com.thriftyrent.vehicle.rent.RentalRecord;
import com.thriftyrent.vehicle.type.Car;
import com.thriftyrent.vehicle.type.Van;
import com.thriftyrent.vehicle.util.DateTime;

/**
 * service to handle all functions
 *
 */
public class ThriftyRentalService {

	List<Vehicle> vehicleList = new ArrayList<>();
	List<RentalRecord> rentalRecordList;

	public boolean addVehicle(Vehicle vehicle) {
		return vehicleList.add(vehicle);
	}

	/**
	 * 
	 * @param vehicleId
	 * @param customerId
	 * @param rentalDate
	 * @param numberOfDays
	 * @return
	 */
	public String rentVehicle(String vehicleId, String customerId, LocalDate rentalDate, String numberOfDays) {
		try {
			int rentalDays = Integer.parseInt(numberOfDays);
			Vehicle vehicleForRent = vehicleList.stream().filter(t -> t.getVehicleId().equals(vehicleId)).findAny()
					.get();
			DateTime rentDate = new DateTime(rentalDate.getDayOfMonth(), rentalDate.getMonthValue(),
					rentalDate.getYear());
			if (!vehicleForRent.rent(customerId, rentDate, rentalDays)) {
				return "vehicle cannot be rented due unsatisfied conditions";
			}
			DateTime returnDate = new DateTime(rentDate, rentalDays);
			int rentalFee = vehicleForRent.rentalRate(rentalDays);
			int weekDay = rentalDate.getDayOfWeek().getValue();
			if (rentalDays < 0) {
				return "minimum rental days should be greater than 0";
			}
			if (vehicleId.startsWith("C") && (weekDay == 1 || weekDay == 2 || weekDay == 3) && rentalDays < 2) {
				return "minimum rental days should be 2";
			}
			if (vehicleId.startsWith("C") && (weekDay == 4 || weekDay == 5) && rentalDays < 3) {
				return "minimum rental days should be 3";
			}
			if (rentalDays > 14) {
				return "maximum rental days should be 14";
			}
			if (vehicleId.startsWith("V")) {
				DateTime lastMaintenanceDate = vehicleForRent.getLastMaintenanceDate();
				int compareWithDate = DateTime.diffDays(lastMaintenanceDate, rentDate);
				if(compareWithDate>=0) {
					return "cannot rent vehicle, rental date before mainenance date";
				}
				DateTime maintenanceTill = new DateTime(lastMaintenanceDate, 12);
				DateTime totalRentalPeriod = new DateTime(rentDate, rentalDays);
				int diff = DateTime.diffDays(totalRentalPeriod, maintenanceTill);
				if (diff > 0) {
					return "cannot rent vehicle, dates out of maintenance schedule";
				}
			}
			RentalRecord rentalRecord = new RentalRecord();
			rentalRecord.setRentDate(rentDate);
			rentalRecord.setActualReturnDate(returnDate);
			rentalRecord.setRentalFee(rentalFee);
			rentalRecord.setRecordId(rentalRecord.generateRecordId(vehicleId, customerId, rentDate));
			rentalRecord.setRecordDate(new DateTime());
			vehicleForRent.setVehicleStatus("rented");
			if (vehicleForRent.getRentalRecordList() == null) {
				rentalRecordList = new ArrayList<>();
				vehicleForRent.setRentalRecordList(new ArrayList<>());
			}
			rentalRecordList = vehicleForRent.getRentalRecordList();
			rentalRecordList.add(rentalRecord);
			Collections.sort(rentalRecordList, new Comparator<RentalRecord>() {
				@Override
				public int compare(RentalRecord o1, RentalRecord o2) {
					Long l1 = o1.getRecordDate().getTime();
					Long l2 = o2.getRecordDate().getTime();
					return l2.compareTo(l1);
				}

			});
			if (rentalRecordList.size() > 10) {
				rentalRecordList.stream().limit(10).collect(Collectors.toList());
			}
			vehicleForRent.setRentalRecordList(rentalRecordList);
			return "success";
		} catch (Exception ex) {
			ex.printStackTrace();
			return "failed with error";
		}
	}

	/**
	 * 
	 * @param vehicleId
	 * @param returnDate
	 * @return
	 */
	public Vehicle returnVehicle(String vehicleId, LocalDate returnDate) {
		Vehicle vehicleForRent = vehicleList.stream().filter(t -> t.getVehicleId().equals(vehicleId)).findAny().get();
		DateTime dateOfReturn = new DateTime(returnDate.getDayOfMonth(), returnDate.getMonthValue(),
				returnDate.getYear());
		RentalRecord latestRentalRecord = vehicleForRent.getRentalRecordList().get(0);
		int diffDaysWithRentDate = DateTime.diffDays(dateOfReturn, latestRentalRecord.getRentDate());
		if (diffDaysWithRentDate < 0) {
			return vehicleForRent;
		}
		int diffDaysWithReturnDate = DateTime.diffDays(latestRentalRecord.getActualReturnDate(), dateOfReturn);
		if (diffDaysWithReturnDate >= 0) {
			int rentalFee = vehicleForRent.rentalRate(diffDaysWithRentDate);
			latestRentalRecord.setRentalFee(rentalFee);
		} else {
			int totalDays = DateTime.diffDays(dateOfReturn, latestRentalRecord.getRentDate());
			int rentalFee = vehicleForRent.rentalRate(totalDays - diffDaysWithReturnDate);
			double lateFee = vehicleForRent.lateRentalRate((-diffDaysWithReturnDate));
			latestRentalRecord.setLateFee(lateFee);
			latestRentalRecord.setRentalFee(rentalFee);
		}
		latestRentalRecord.setReturnDate(dateOfReturn);
		vehicleForRent.setVehicleStatus("Available");
		return vehicleForRent;
	}

	/**
	 * 
	 * @param vehicleId
	 * @return
	 */
	public Vehicle maintainVehicle(String vehicleId) {
		Vehicle vehicleForRent = vehicleList.stream().filter(t -> t.getVehicleId().equals(vehicleId)).findAny().get();
		String vehicleStatus = vehicleForRent.getVehicleStatus();
		if (vehicleForRent.getVehicleId().startsWith("C")) {
			if (vehicleStatus.equals("Available")) {
				vehicleForRent.setVehicleStatus("umaintenance");
				return vehicleForRent;
			}
		} else {
			if (vehicleStatus.equals("Available")) {
				DateTime lastMaintenanceDate = vehicleForRent.getLastMaintenanceDate();
				DateTime currentTime = new DateTime();
				int diff = DateTime.diffDays(currentTime, lastMaintenanceDate);
				if (diff < 12) {
					return vehicleForRent;
				} else {
					vehicleForRent.setVehicleStatus("umaintenance");
					return vehicleForRent;
				}
			}
		}
		return vehicleForRent;
	}

	/**
	 * 
	 * @param vehicleId
	 * @param completionDate
	 * @return
	 */
	public String completeMaintenance(String vehicleId,LocalDate completionDate) {
		Vehicle vehicleForRent = vehicleList.stream().filter(t -> t.getVehicleId().equals(vehicleId)).findAny().get();
		if(completionDate!=null) {
			DateTime dateOfCompletion = new DateTime(completionDate.getDayOfMonth(), completionDate.getMonthValue(),
					completionDate.getYear());
			vehicleForRent.setLastMaintenanceDate(dateOfCompletion);
		}
		String vehicleStatus = vehicleForRent.getVehicleStatus();
		if (vehicleStatus.equals("umaintenance")) {
			vehicleForRent.setVehicleStatus("Available");
			return "success";
		}
		return vehicleStatus;
	}

	/**
	 * vehicle display builder
	 * @return
	 */
	public String displayAllVehicles() {
		StringBuilder detailsBuilder = new StringBuilder();
		for (Vehicle vehicle : vehicleList) {
			detailsBuilder.append(vehicle.getDetails()).append("\n");
		}
		return detailsBuilder.toString();
	}

	/**
	 * 
	 * @param vehicleId
	 * @return
	 */
	public boolean checkIfIdExists(String vehicleId) {
		return vehicleList.stream().anyMatch(t -> t.getVehicleId().equalsIgnoreCase(vehicleId));
	}

	/**
	 * 
	 * @param vehicleType
	 * @return
	 */
	public boolean validateVehicle(String vehicleType) {
		if (vehicleType.equalsIgnoreCase("Car") || vehicleType.equalsIgnoreCase("Van")) {
			return true;
		}
		return false;
	}

	/**
	 * 
	 * @param vehicleType
	 * @return
	 */
	public Vehicle returnValidVehicleType(String vehicleType) {
		if (vehicleType.equalsIgnoreCase("Car")) {
			return new Car();
		} else {
			return new Van();
		}
	}
}
