package com.thriftyrent.vehicle.type;

import com.thriftyrent.vehicle.Vehicle;
import com.thriftyrent.vehicle.util.DateTime;
import com.thriftyrent.vehicle.util.ValidationUtil;

public class Car extends Vehicle{

	public boolean validateSeats(String numberOfSeats) {
		if(ValidationUtil.validateNumericField(numberOfSeats)) {
			if(Integer.parseInt(numberOfSeats)==4 || Integer.parseInt(numberOfSeats)==7) {
				return true;
			}
		}return false;
	}
	
	public boolean rent(String customerId, DateTime rentDate, int
			numOfRentDay) {
		if(this.getVehicleStatus().equals("rented")||this.getVehicleStatus().equals("umaintenance")) {
			return false;
		}else if(this.getNumberOfSeats()==4 &&(numOfRentDay<2||numOfRentDay<0)) {
			return false;
		}else if(this.getNumberOfSeats()==7 &&(numOfRentDay<3||numOfRentDay<0)) {
			return false;
		}
		return true;
	}
	
	
	public int rentalRate(int diffDays) {
		if(this.getNumberOfSeats()==4) {
			return diffDays*78;
		}else {
			return diffDays*113;
		}
	}
	
	public double lateRentalRate(int days) {
		if(this.getNumberOfSeats()==4) {
			return 1.25*78*days;
		}else {
			return 1.25*113*days;
		}
	}
	
	
	public boolean validateId(String vehicleId) {
		if(vehicleId.startsWith("C_")) {
			return true;
		}return false;
	}
	
}
