package com.thriftyrent.vehicle.type;

import com.thriftyrent.vehicle.Vehicle;
import com.thriftyrent.vehicle.util.DateTime;
import com.thriftyrent.vehicle.util.ValidationUtil;

public class Van extends Vehicle{

	public boolean validateSeats(String numberOfSeats) {
		if(ValidationUtil.validateNumericField(numberOfSeats)) {
			if(Integer.parseInt(numberOfSeats)==15) {
				return true;
			}
		}return false;
	}
	
	public boolean rent(String customerId, DateTime rentDate, int
			numOfRentDay) {
		if(this.getVehicleStatus().equals("rented")||this.getVehicleStatus().equals("umaintenance")) {
			return false;
		}
		return true;
	}
	
	public boolean validateId(String vehicleId) {
		if(vehicleId.startsWith("V_")) {
			return true;
		}return false;
	}
	
	public int rentalRate(int diffDays) {
		return diffDays*235;
	}
	
	public double lateRentalRate(int days) {
		return 299*days;
	}
}
