package com.thriftyrent.vehicle.rent;

import com.thriftyrent.vehicle.util.DateTime;

public class RentalRecord {

	private String recordId;
	private DateTime rentDate;
	private DateTime returnDate;
	private DateTime actualReturnDate;
	private int rentalFee;
	private double lateFee;
	private DateTime recordDate;
	
	
	
	public DateTime getRecordDate() {
		return recordDate;
	}


	public void setRecordDate(DateTime recordDate) {
		this.recordDate = recordDate;
	}


	public String getRecordId() {
		return recordId;
	}


	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}


	public DateTime getRentDate() {
		return rentDate;
	}


	public void setRentDate(DateTime rentDate) {
		this.rentDate = rentDate;
	}


	public DateTime getReturnDate() {
		return returnDate;
	}


	public void setReturnDate(DateTime returnDate) {
		this.returnDate = returnDate;
	}


	public DateTime getActualReturnDate() {
		return actualReturnDate;
	}


	public void setActualReturnDate(DateTime actualReturnDate) {
		this.actualReturnDate = actualReturnDate;
	}


	public int getRentalFee() {
		return rentalFee;
	}


	public void setRentalFee(int rentalFee) {
		this.rentalFee = rentalFee;
	}


	public double getLateFee() {
		return lateFee;
	}


	public void setLateFee(double lateFee) {
		this.lateFee = lateFee;
	}


	public String toString() {
		String rtDate = null;
		if(this.returnDate==null) {
			rtDate = "none";
		}else {
			rtDate = this.returnDate.toString();
		}
		String rtFee = null;
		if(this.rentalFee==0) {
			rtFee = "none";
		}else {
			rtFee = Integer.toString(this.rentalFee);
		}
		String lFee = null;
		if(this.lateFee==0.0) {
			lFee = "none";
		}else {
			lFee = Double.toString(this.lateFee);
		}
		return recordId+":"+rentDate+":"+actualReturnDate+":"+rtDate+":"+rtFee+":"+lFee;
	}
	
	
	public String getDetails() {
		StringBuilder rentalRecordBuilder = new StringBuilder();
		String rentalRecordId = String.format("Record ID:%35s\n", this.recordId);
		String rentDate = String.format("Rent Date:%35s\n", this.rentDate);
		String estimatedReturnDate = String.format("Estimated Return Date:%23s\n", this.actualReturnDate);
		rentalRecordBuilder.append(rentalRecordId).append(rentDate).append(estimatedReturnDate);
		if(this.returnDate!=null) {
			String actReturnDate = String.format("Return Date:%33s\n", this.returnDate);
			rentalRecordBuilder.append(actReturnDate);
			String rentFee = String.format("Rental Fee:%34s\n", this.rentalFee);
			rentalRecordBuilder.append(rentFee);
			String lateFee =  String.format("Late Fee:%36s\n", this.lateFee);
			rentalRecordBuilder.append(lateFee);
		}
		return rentalRecordBuilder.toString();
	}
	
	public String generateRecordId(String vehicleId,String customerId,DateTime rentDate) {
		StringBuilder recordIdBuilder = new StringBuilder();
		recordIdBuilder.append(vehicleId).append("_").append(customerId).append("_").append(rentDate.getEightDigitDate());
		return recordIdBuilder.toString();
	}
}
