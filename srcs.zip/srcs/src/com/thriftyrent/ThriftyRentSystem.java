package com.thriftyrent;

import com.thriftyrent.vehicle.service.ThriftyRentalMenuService;

public class ThriftyRentSystem {

	private static ThriftyRentalMenuService menuService  = new ThriftyRentalMenuService();
	/**
	 * main execution point of code
	 * @param args
	 */
	public static void main(String[] args) {
		menuService.createMenu();
	}

}
